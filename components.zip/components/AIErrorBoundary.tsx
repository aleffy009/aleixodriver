import React, { Component, ErrorInfo, ReactNode } from 'react';
import { analyzeAppError, AIErrorAnalysis } from '../services/geminiService';
import { api } from '../services/api';

interface Props {
  children?: ReactNode;
}

interface State {
  hasError: boolean;
  isRecovering: boolean;
  aiAnalysis: AIErrorAnalysis | null;
}

class AIErrorBoundary extends Component<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = {
      hasError: false,
      isRecovering: false,
      aiAnalysis: null
    };
  }

  static getDerivedStateFromError(_: Error): State {
    return { hasError: true, isRecovering: true, aiAnalysis: null };
  }

  componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error("Uncaught error:", error, errorInfo);
    
    analyzeAppError(error.message, errorInfo.componentStack || "")
        .then((analysis) => {
            this.setState({ aiAnalysis: analysis });
            api.reportError({
                errorMessage: error.message,
                componentStack: errorInfo.componentStack || "",
                aiAnalysis: analysis
            });
            this.executeAutoFix(analysis);
        })
        .catch(() => {
            this.executeAutoFix({ 
                userMessage: "Recuperando sistema...", 
                action: "AUTO_FIX",
                technicalDetails: "Fallback",
                suggestedFix: "-",
                severity: "LOW",
                autoFixStrategy: "RELOAD_ONLY"
            });
        });
  }

  executeAutoFix = (analysis: AIErrorAnalysis) => {
      setTimeout(() => {
          switch (analysis.autoFixStrategy) {
              case 'RESET_STORAGE':
                  localStorage.removeItem('aleixo_ride_state'); 
                  localStorage.removeItem('aleixo_user'); 
                  window.location.reload();
                  break;
              case 'LOGOUT_FORCE':
                  localStorage.clear();
                  window.location.href = '/#login';
                  window.location.reload();
                  break;
              default:
                  window.location.reload();
                  break;
          }
      }, 2500);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-slate-900 flex flex-col items-center justify-center p-6 text-center">
            <h1 className="text-2xl font-bold text-white mb-2">
                {this.state.aiAnalysis ? "Corrigindo Automaticamente..." : "Analisando Erro..."}
            </h1>
            <div className="w-full h-1 bg-slate-800 rounded-full overflow-hidden mt-4 max-w-xs mx-auto">
                <div className="h-full bg-green-500 animate-progress-bar"></div>
            </div>
        </div>
      );
    }
    return this.props.children;
  }
}

export default AIErrorBoundary;