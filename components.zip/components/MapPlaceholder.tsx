
import React, { useEffect, useRef } from 'react';
import { NEIGHBORHOOD_CENTER } from '../constants';
import * as L from 'leaflet';
import { useTheme } from '../contexts/ThemeContext';

interface MapPlaceholderProps {
  location: { lat: number; lng: number } | null;
  className?: string;
  destination?: { lat: number; lng: number } | null;
  showRoute?: boolean;
}

const MapPlaceholder: React.FC<MapPlaceholderProps> = ({ location, className, destination, showRoute }) => {
  const { theme } = useTheme();
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);
  const tileLayerRef = useRef<L.TileLayer | null>(null);
  const driverMarkerRef = useRef<L.Marker | null>(null);
  const destMarkerRef = useRef<L.Marker | null>(null);
  const routeLineRef = useRef<L.Polyline | null>(null);

  // Initialize Map safely
  useEffect(() => {
    if (!mapContainerRef.current) return;
    if (mapInstanceRef.current) return;

    try {
        const initialLat = location ? location.lat : NEIGHBORHOOD_CENTER.lat;
        const initialLng = location ? location.lng : NEIGHBORHOOD_CENTER.lng;

        const map = L.map(mapContainerRef.current, {
            zoomControl: false,
            attributionControl: false
        }).setView([initialLat, initialLng], 16);

        mapInstanceRef.current = map;
    } catch (e) {
        console.error("Leaflet Init Error:", e);
    }

    return () => {
        if (mapInstanceRef.current) {
            mapInstanceRef.current.remove();
            mapInstanceRef.current = null;
        }
    };
  }, []);

  // Update Tile Layer
  useEffect(() => {
    const map = mapInstanceRef.current;
    if (!map) return;

    if (tileLayerRef.current) {
        tileLayerRef.current.remove();
    }

    const tileUrl = theme === 'dark' 
        ? 'https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png'
        : 'https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png';

    tileLayerRef.current = L.tileLayer(tileUrl, {
        maxZoom: 20
    }).addTo(map);

  }, [theme]); 

  // Update Markers
  useEffect(() => {
    const map = mapInstanceRef.current;
    if (!map || !location) return;

    try {
        // PROFESSIONAL ICONS
        const driverIcon = L.divIcon({
            className: 'custom-driver-icon',
            html: `
                <div style="
                    font-size: 32px; 
                    filter: drop-shadow(0 4px 6px rgba(0,0,0,0.3)); 
                    transform-origin: center;
                    display: flex; justify-content: center; align-items: center;
                ">
                    🚗
                </div>`,
            iconSize: [40, 40],
            iconAnchor: [20, 20]
        });

        if (driverMarkerRef.current) {
            driverMarkerRef.current.setLatLng([location.lat, location.lng]);
        } else {
            driverMarkerRef.current = L.marker([location.lat, location.lng], { icon: driverIcon }).addTo(map);
        }

        if (!showRoute || !destination) {
            map.panTo([location.lat, location.lng], { animate: true });
        }
    } catch(e) { console.warn("Marker update error", e) }

  }, [location, showRoute, destination]);

  // Update Route
  useEffect(() => {
    const map = mapInstanceRef.current;
    if (!map) return;

    try {
        if (showRoute && destination && location) {
            const destIcon = L.divIcon({
                className: 'custom-dest-icon',
                html: `
                    <div style="position: relative;">
                        <div style="
                            font-size: 32px; 
                            filter: drop-shadow(0 4px 6px rgba(239,68,68,0.5));
                            animation: bounce 1s infinite;
                        ">📍</div>
                        <div style="
                            position: absolute; bottom: 0; left: 50%; transform: translateX(-50%);
                            width: 10px; height: 4px; background: rgba(0,0,0,0.3); border-radius: 50%;
                            filter: blur(2px);
                        "></div>
                    </div>`,
                iconSize: [40, 40],
                iconAnchor: [20, 35]
            });

            if (destMarkerRef.current) {
                destMarkerRef.current.setLatLng([destination.lat, destination.lng]);
            } else {
                destMarkerRef.current = L.marker([destination.lat, destination.lng], { icon: destIcon }).addTo(map);
            }

            const latlngs = [
                [location.lat, location.lng],
                [destination.lat, destination.lng]
            ];

            const routeColor = theme === 'dark' ? '#4ade80' : '#16a34a';

            if (routeLineRef.current) {
                routeLineRef.current.setLatLngs(latlngs as any);
                routeLineRef.current.setStyle({ 
                    color: routeColor,
                    dashArray: '10, 10', 
                    className: 'animate-route' 
                });
            } else {
                routeLineRef.current = L.polyline(latlngs as any, {
                    color: routeColor,
                    weight: 6,
                    opacity: 0.9,
                    lineCap: 'round',
                    dashArray: '10, 10', 
                    className: 'animate-route'
                }).addTo(map);
            }
            
            map.fitBounds(L.latLngBounds(latlngs as any), { padding: [50, 50] });

        } else {
            if (destMarkerRef.current) {
                destMarkerRef.current.remove();
                destMarkerRef.current = null;
            }
            if (routeLineRef.current) {
                routeLineRef.current.remove();
                routeLineRef.current = null;
            }
        }
    } catch(e) { console.warn("Route update error", e) }

  }, [destination, showRoute, location, theme]);

  return (
    <div className={`overflow-hidden relative group ${className || 'w-full h-full'} ${theme === 'light' ? 'bg-gray-200' : 'bg-slate-900'}`}>
       {!location && (
          <div className="absolute inset-0 flex items-center justify-center bg-white/90 dark:bg-slate-900/90 z-20 pointer-events-none">
             <div className="text-center">
                 <div className="w-8 h-8 border-4 border-green-500 border-t-transparent rounded-full animate-spin mx-auto mb-2"></div>
                 <p className="text-green-600 dark:text-green-400 text-xs font-bold animate-pulse">Buscando Satélite GPS...</p>
             </div>
          </div>
       )}
       
       <div ref={mapContainerRef} className="w-full h-full z-0" />
    </div>
  );
};

export default MapPlaceholder;
