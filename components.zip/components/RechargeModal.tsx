
import React, { useState, useEffect } from 'react';
import { api } from '../services/api';
import { RechargeOption } from '../types';

interface RechargeModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const RechargeModal: React.FC<RechargeModalProps> = ({ isOpen, onClose }) => {
  const [options, setOptions] = useState<RechargeOption[]>([]);
  const [selectedOption, setSelectedOption] = useState<RechargeOption | null>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (isOpen) {
        setLoading(true);
        api.getRechargeOptions().then(res => {
            if (res.success) setOptions(res.options);
            setLoading(false);
        });
    } else {
        setSelectedOption(null);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[70] flex items-center justify-center p-4 animate-fade-in">
      <div className="absolute inset-0 bg-slate-900/90 backdrop-blur-sm" onClick={onClose}></div>
      
      <div className="bg-slate-800 w-full max-w-md rounded-2xl shadow-2xl border border-slate-700 relative z-10 overflow-hidden flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-700 bg-slate-800/50">
            <h2 className="text-xl font-bold text-white flex items-center gap-2">
                <span className="text-yellow-400">⚡</span> Recarregar Carteira
            </h2>
            <button onClick={onClose} className="p-2 text-slate-400 hover:text-white">✕</button>
        </div>

        <div className="p-6">
            {!selectedOption ? (
                // VIEW 1: SELECT VALUE
                <div className="space-y-4">
                    <p className="text-slate-400 text-sm text-center mb-6">Selecione um valor para adicionar créditos à sua conta e continuar aceitando corridas.</p>
                    
                    {loading ? (
                        <div className="flex justify-center"><div className="w-8 h-8 border-2 border-green-500 border-t-transparent rounded-full animate-spin"></div></div>
                    ) : (
                        <div className="grid grid-cols-2 gap-3">
                            {options.map(opt => (
                                <button
                                    key={opt.id}
                                    onClick={() => setSelectedOption(opt)}
                                    className="bg-slate-700 hover:bg-slate-600 border border-slate-600 hover:border-green-500 rounded-xl p-4 flex flex-col items-center gap-2 transition-all active:scale-95 group"
                                >
                                    <span className="text-slate-400 text-xs font-bold uppercase group-hover:text-green-400">Recarga de</span>
                                    <span className="text-2xl font-black text-white group-hover:text-green-400">R$ {opt.value},00</span>
                                </button>
                            ))}
                        </div>
                    )}
                </div>
            ) : (
                // VIEW 2: SHOW QR CODE
                <div className="flex flex-col items-center animate-slide-up">
                    <button onClick={() => setSelectedOption(null)} className="self-start text-xs text-slate-400 hover:text-white mb-4">← Voltar</button>
                    
                    <h3 className="text-2xl font-bold text-green-400 mb-2">R$ {selectedOption.value},00</h3>
                    <p className="text-slate-400 text-sm mb-6">Escaneie o QR Code abaixo para pagar</p>
                    
                    <div className="bg-white p-4 rounded-xl shadow-lg mb-6">
                        {selectedOption.qrCodeUrl ? (
                            <img src={selectedOption.qrCodeUrl} alt="QR Code" className="w-48 h-48 object-contain" />
                        ) : (
                            <div className="w-48 h-48 flex items-center justify-center bg-gray-100 text-gray-400 text-center text-xs p-4 border-2 border-dashed border-gray-300">
                                Aguardando QR Code do Admin...
                            </div>
                        )}
                    </div>

                    <p className="text-xs text-slate-500 text-center max-w-xs mb-6">
                        Após o pagamento, envie o comprovante para o suporte para liberação imediata.
                    </p>

                    <button onClick={onClose} className="w-full bg-green-500 hover:bg-green-600 text-slate-900 font-bold py-3 rounded-xl">
                        Já paguei (Enviar Comprovante)
                    </button>
                </div>
            )}
        </div>
      </div>
    </div>
  );
};

export default RechargeModal;
