
import React, { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useTheme } from '../contexts/ThemeContext';
import { UserRole } from '../types';
import SettingsModal from './SettingsModal';

const Navbar = () => {
  const { user, logout } = useAuth();
  const { theme, toggleTheme } = useTheme();
  const [menuOpen, setMenuOpen] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [settingsTab, setSettingsTab] = useState<'profile' | 'settings'>('profile');

  const handleOpenSettings = (tab: 'profile' | 'settings') => {
      setSettingsTab(tab);
      setShowSettings(true);
      setMenuOpen(false);
  };

  return (
    <>
    <nav className="w-full bg-white dark:bg-slate-800 border-b border-gray-200 dark:border-slate-700 sticky top-0 z-50 transition-colors duration-300">
      <div className="max-w-6xl mx-auto px-4 h-16 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="bg-green-500 w-8 h-8 rounded-lg flex items-center justify-center font-bold text-slate-900 shadow-sm">A</div>
          <span className="text-xl font-bold tracking-tight text-slate-800 dark:text-white">
            Aleixo<span className="text-green-600 dark:text-green-400">Drive</span>
          </span>
        </div>

        <div className="flex items-center gap-3">
          {/* Theme Toggle */}
          <button 
            onClick={toggleTheme}
            className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300 transition-colors"
            title={theme === 'dark' ? "Mudar para Modo Claro" : "Mudar para Modo Escuro"}
          >
            {theme === 'dark' ? '☀️' : '🌙'}
          </button>

          {user ? (
            <div className="relative">
              <button 
                onClick={() => setMenuOpen(!menuOpen)}
                className="flex items-center gap-2 hover:bg-gray-100 dark:hover:bg-slate-700 p-2 rounded-lg transition-colors"
              >
                <div className="text-right hidden sm:block">
                  <p className="text-sm font-medium text-slate-800 dark:text-white">{user.name}</p>
                  <p className="text-xs text-slate-500 dark:text-slate-400">{user.role === UserRole.DRIVER ? 'Motorista' : (user.role === UserRole.ADMIN ? 'Admin' : 'Passageiro')}</p>
                </div>
                <div className="w-10 h-10 bg-gradient-to-br from-green-400 to-blue-500 rounded-full flex items-center justify-center text-white font-bold shadow-md border-2 border-white dark:border-slate-800">
                  {user.name.charAt(0).toUpperCase()}
                </div>
              </button>

              {menuOpen && (
                <div className="absolute right-0 mt-2 w-56 bg-white dark:bg-slate-800 border border-gray-200 dark:border-slate-700 rounded-xl shadow-2xl py-2 overflow-hidden z-50 animate-fade-in">
                  <div className="px-4 py-3 border-b border-gray-200 dark:border-slate-700 bg-gray-50 dark:bg-slate-800/50 sm:hidden">
                     <p className="text-slate-800 dark:text-white font-bold">{user.name}</p>
                     <p className="text-xs text-slate-500 dark:text-slate-400">{user.role}</p>
                  </div>
                  
                  <button 
                    onClick={() => handleOpenSettings('profile')}
                    className="w-full text-left px-4 py-3 text-slate-600 dark:text-slate-300 hover:bg-gray-100 dark:hover:bg-slate-700 hover:text-green-600 dark:hover:text-white flex items-center gap-3 transition-colors"
                  >
                    <span>👤</span> Meu Perfil
                  </button>
                  
                  <button 
                    onClick={() => handleOpenSettings('settings')}
                    className="w-full text-left px-4 py-3 text-slate-600 dark:text-slate-300 hover:bg-gray-100 dark:hover:bg-slate-700 hover:text-green-600 dark:hover:text-white flex items-center gap-3 transition-colors"
                  >
                    <span>⚙️</span> Configurações
                  </button>
                  
                  {user.role === UserRole.ADMIN && (
                     <button onClick={() => window.location.hash = '#admin'} className="w-full text-left px-4 py-3 text-yellow-600 dark:text-yellow-400 hover:bg-gray-100 dark:hover:bg-slate-700 flex items-center gap-3">
                        <span>🛡️</span> Painel Admin
                     </button>
                  )}
                  
                  <div className="border-t border-gray-200 dark:border-slate-700 mt-1"></div>
                  <button 
                    onClick={() => { setMenuOpen(false); logout(); }}
                    className="w-full text-left px-4 py-3 text-red-500 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-500/10 hover:text-red-600 dark:hover:text-red-300 flex items-center gap-3 transition-colors"
                  >
                    <span>🚪</span> Sair
                  </button>
                </div>
              )}
            </div>
          ) : (
            <a href="#login" className="text-sm font-medium text-slate-600 dark:text-slate-300 hover:text-green-600 dark:hover:text-white transition-colors">
              Entrar / Cadastrar
            </a>
          )}
        </div>
      </div>
    </nav>

    {/* Integrated Modal */}
    <SettingsModal 
        isOpen={showSettings} 
        onClose={() => setShowSettings(false)} 
        defaultTab={settingsTab}
    />
    </>
  );
};

export default Navbar;
