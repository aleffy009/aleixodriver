
import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { User, UserRole } from '../types';
import { api } from '../services/api';

interface AuthContextType {
  user: User | null;
  login: (email: string, pass: string, role: UserRole) => Promise<boolean>;
  signup: (name: string, email: string, pass: string, role: UserRole, extraData?: any) => Promise<boolean>;
  updateProfile: (data: Partial<User>) => Promise<void>;
  logout: () => void;
  isAuthenticated: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider = ({ children }: { children?: ReactNode }) => {
  const [user, setUser] = useState<User | null>(null);

  useEffect(() => {
    const stored = localStorage.getItem('aleixo_user');
    if (stored) {
      setUser(JSON.parse(stored));
    }
  }, []);

  const login = async (email: string, pass: string, role: UserRole): Promise<boolean> => {
    try {
        const response = await api.login(email, pass, role);
        
        if (response.success) {
            const userData = { ...response.user, role: response.user.role || role };
            setUser(userData);
            localStorage.setItem('aleixo_user', JSON.stringify(userData));
            return true;
        }
        return false;
    } catch (error) {
        console.error("Auth Login Error", error);
        return false;
    }
  };

  const signup = async (name: string, email: string, pass: string, role: UserRole, extraData?: any): Promise<boolean> => {
     try {
         const payload = {
             name, 
             email, 
             password: pass, 
             role,
             // Extra Data Spread (Phone, CPF, Vehicle info, Photo)
             ...extraData
         };
         
         const response = await api.signup(payload);
         if (response.success) {
             setUser(response.user);
             localStorage.setItem('aleixo_user', JSON.stringify(response.user));
             return true;
         }
         return false;
     } catch (error) {
         console.error("Auth Signup Error", error);
         return false;
     }
  };

  const updateProfile = async (data: Partial<User>) => {
      if (!user) return;
      
      const updatedLocal = { ...user, ...data };
      setUser(updatedLocal);
      localStorage.setItem('aleixo_user', JSON.stringify(updatedLocal));

      await api.updateProfile(user.id, data);
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('aleixo_user');
  };

  return (
    <AuthContext.Provider value={{ user, login, signup, logout, updateProfile, isAuthenticated: !!user }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) throw new Error("useAuth must be used within AuthProvider");
  return context;
};
