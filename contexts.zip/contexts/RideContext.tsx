import React, { createContext, useContext, useState, useEffect, ReactNode, useRef } from 'react';
import { io, Socket } from 'socket.io-client';
import { Ride, RideStatus, ChatMessage, UserRole } from '../types';
import { useAuth } from './AuthContext';

const SERVER_URL = 'http://localhost:4000';

interface RideContextType {
  currentRide: Ride | null;
  requestRide: (ride: Omit<Ride, 'id' | 'status' | 'timestamp'>) => void;
  updateRideStatus: (status: RideStatus) => void;
  allRides: Ride[];
  acceptRide: (rideId: string, driverId: string) => void;
  cancelRide: () => void;
  userLocation: { lat: number; lng: number } | null;
  updateUserLocation: (lat: number, lng: number) => void;
  messages: ChatMessage[];
  sendMessage: (senderId: string, text: string) => void;
  notifyTyping: () => void;
  isPeerTyping: boolean;
  isConnected: boolean;
  socket: Socket | null;
}

const RideContext = createContext<RideContextType | undefined>(undefined);

export const RideProvider = ({ children }: { children?: ReactNode }) => {
  const { user } = useAuth();
  const [socket, setSocket] = useState<Socket | null>(null);
  const [isConnected, setIsConnected] = useState(false);
  
  const [currentRide, setCurrentRide] = useState<Ride | null>(null);
  const [allRides, setAllRides] = useState<Ride[]>([]);
  const [userLocation, setUserLocation] = useState<{ lat: number; lng: number } | null>(null);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  
  // Typing State
  const [isPeerTyping, setIsPeerTyping] = useState(false);
  const typingTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  // --- SOCKET INITIALIZATION & AUTO-RECOVERY ---
  useEffect(() => {
    let newSocket: Socket | null = null;
    
    if (typeof io === 'undefined') {
        console.warn("Socket.IO failed to load.");
        return;
    }

    try {
        newSocket = io(SERVER_URL, {
            transports: ['websocket', 'polling'], 
            reconnectionAttempts: 5, // Aumentado para maior resiliência
            reconnectionDelay: 1000,
            timeout: 5000,
            autoConnect: true
        });

        newSocket.on('connect', () => {
            console.log("Connected to Socket Server");
            setIsConnected(true);
        });

        newSocket.on('connect_error', (err) => {
            // Não marca desconectado imediatamente para evitar flicker na UI
            console.warn("Connection warning:", err.message);
        });

        newSocket.on('disconnect', () => setIsConnected(false));

        newSocket.on('sync-rides', (rides: Ride[]) => {
            setAllRides(rides);
        });

        newSocket.on('new-ride', (ride: Ride) => {
            setAllRides(prev => {
                // LOGIC FIX: Avoid duplicates logic
                if (prev.some(r => r.id === ride.id)) return prev;
                // Avoid duplication if user just created it locally (timestamp check approx)
                const isDuplicateLocal = prev.some(r => 
                    r.passengerId === ride.passengerId && 
                    Math.abs(r.timestamp - ride.timestamp) < 2000
                );
                if (isDuplicateLocal) return prev;
                
                return [...prev, ride];
            });
        });

        newSocket.on('ride-updated', (updatedRide: Ride) => {
            setAllRides(prev => prev.map(r => r.id === updatedRide.id ? updatedRide : r));
            
            if (user) {
                const isMyRide = updatedRide.passengerId === user.id || updatedRide.driverId === user.id;
                if (isMyRide) {
                    setCurrentRide(updatedRide);
                    
                    if (updatedRide.status === RideStatus.ACCEPTED) {
                        setMessages(prev => {
                            if (prev.some(m => m.id.startsWith('sys-'))) return prev;
                            return [...prev, {
                                id: `sys-${Date.now()}`,
                                senderId: 'system',
                                text: 'Corrida aceita! Chat iniciado.',
                                timestamp: Date.now(),
                                isSystem: true
                            }];
                        });
                    }
                    if (updatedRide.status === RideStatus.COMPLETED || updatedRide.status === RideStatus.CANCELLED) {
                       setTimeout(() => {
                           setCurrentRide(null);
                           setMessages([]);
                       }, 5000); 
                    }
                }
            }
        });

        newSocket.on('receive-message', (msg: ChatMessage) => {
            setMessages(prev => {
                if (prev.some(m => m.id === msg.id)) return prev;
                return [...prev, msg];
            });
            // Stop typing indicator if message received
            setIsPeerTyping(false);
        });

        // TYPING EVENT LISTENER
        newSocket.on('display-typing', ({ rideId, userId }) => {
            // Só mostra se for da mesma corrida e NÃO for eu mesmo
            if (currentRide && currentRide.id === rideId && userId !== user?.id) {
                setIsPeerTyping(true);
                
                // Limpa timeout anterior
                if (typingTimeoutRef.current) clearTimeout(typingTimeoutRef.current);
                
                // Define novo timeout para esconder "Digitando..." após 3 segundos
                typingTimeoutRef.current = setTimeout(() => {
                    setIsPeerTyping(false);
                }, 3000);
            }
        });

        setSocket(newSocket);
    } catch (e) {
        console.warn("Socket init critical failure", e);
    }

    return () => {
        if(newSocket) newSocket.close();
    };
  }, [user, currentRide]); // Added currentRide dependência para o typing check

  // --- ACTIONS ---

  const requestRide = (rideData: Omit<Ride, 'id' | 'status' | 'timestamp'>) => {
    // 1. Otimista (Local)
    const tempId = `local-${Date.now()}`;
    const newRide: Ride = {
        ...rideData,
        id: tempId,
        status: RideStatus.PENDING,
        timestamp: Date.now()
    };
    
    setCurrentRide(newRide);
    setAllRides(prev => [...prev, newRide]);

    // 2. Server
    if (socket && isConnected) {
        socket.emit('request-ride', rideData);
        // Remove local optimistic ride after short delay to allow server sync to take over
        setTimeout(() => {
            setAllRides(prev => prev.filter(r => r.id !== tempId));
        }, 2000);
    }
  };

  const acceptRide = (rideId: string, driverId: string) => {
      // 1. Local
      const updatedRides = allRides.map(r => 
         r.id === rideId ? { ...r, status: RideStatus.ACCEPTED, driverId } : r
      );
      const targetRide = updatedRides.find(r => r.id === rideId);
      
      setAllRides(updatedRides as Ride[]);
      if (targetRide && (targetRide.passengerId === user?.id || targetRide.driverId === user?.id)) {
          setCurrentRide(targetRide as Ride);
      }

      // 2. Server
      if (socket && isConnected) {
          socket.emit('accept-ride', { rideId, driverId });
      }
  };

  const updateRideStatus = (status: RideStatus) => {
      if (!currentRide) return;
      
      const updatedRide = { ...currentRide, status };
      setCurrentRide(updatedRide);
      setAllRides(prev => prev.map(r => r.id === updatedRide.id ? updatedRide : r));

      if (status === RideStatus.COMPLETED || status === RideStatus.CANCELLED) {
           setTimeout(() => {
               if (currentRide?.id === updatedRide.id) setCurrentRide(null);
               setMessages([]);
           }, 5000); 
      }

      if (socket && isConnected) {
          socket.emit('update-ride-status', { rideId: currentRide.id, status });
      }
  };

  const cancelRide = () => {
      if (!currentRide) return;
      
      const updatedRide = { ...currentRide, status: RideStatus.CANCELLED };
      setCurrentRide(null);
      setAllRides(prev => prev.map(r => r.id === updatedRide.id ? updatedRide : r));

      if (socket && isConnected) {
          socket.emit('update-ride-status', { rideId: currentRide.id, status: RideStatus.CANCELLED });
      }
  };

  const updateUserLocation = (lat: number, lng: number) => {
      setUserLocation({ lat, lng });
      if (socket && isConnected && user && user.role === 'DRIVER') {
          socket.emit('update-location', { userId: user.id, role: user.role, lat, lng });
      }
  };

  const sendMessage = (senderId: string, text: string) => {
      const msg: ChatMessage = {
          id: `msg-${Date.now()}-${Math.random()}`,
          senderId,
          text,
          timestamp: Date.now()
      };
      
      setMessages(prev => [...prev, msg]);
      
      if (socket && isConnected) {
          socket.emit('send-message', msg);
      }
  };

  const notifyTyping = () => {
      if (socket && isConnected && currentRide && user) {
          socket.emit('typing', { rideId: currentRide.id, userId: user.id });
      }
  };

  return (
    <RideContext.Provider value={{ 
        currentRide, 
        requestRide, 
        updateRideStatus, 
        allRides, 
        acceptRide, 
        cancelRide, 
        userLocation, 
        updateUserLocation, 
        messages, 
        sendMessage,
        notifyTyping, 
        isPeerTyping,
        isConnected,
        socket 
    }}>
      {children}
    </RideContext.Provider>
  );
};

export const useRide = () => {
  const context = useContext(RideContext);
  if (!context) throw new Error("useRide must be used within RideProvider");
  return context;
};