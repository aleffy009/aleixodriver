
import React, { useState, useEffect } from 'react';
import { useRide } from '../contexts/RideContext';
import { useAuth } from '../contexts/AuthContext';
import { PlaceSuggestion, RideStatus, PricingRules } from '../types';
import { getPlaceSuggestions, estimateTripDetails, getAddressFromCoordinates } from '../services/geminiService';
import { api } from '../services/api'; // Nova importação
import ChatWindow from './ChatWindow';

const RideRequest = () => {
  const { requestRide, currentRide, cancelRide, updateUserLocation } = useRide();
  const { user } = useAuth();
  
  // Pricing State
  const [pricing, setPricing] = useState<PricingRules | null>(null);

  // Location State
  const [originAddress, setOriginAddress] = useState<string>('');
  const [coords, setCoords] = useState<{lat: number, lng: number} | null>(null);
  const [locationStatus, setLocationStatus] = useState<'idle' | 'loading' | 'success' | 'error'>('idle');
  
  // Destination State
  const [destination, setDestination] = useState('');
  const [destCoords, setDestCoords] = useState<{lat: number, lng: number} | null>(null);
  
  // Suggestions State
  const [originSuggestions, setOriginSuggestions] = useState<PlaceSuggestion[]>([]);
  const [destSuggestions, setDestSuggestions] = useState<PlaceSuggestion[]>([]);
  const [isSearchingOrigin, setIsSearchingOrigin] = useState(false);
  const [isSearchingDest, setIsSearchingDest] = useState(false);
  
  // UX Control
  const [activeField, setActiveField] = useState<'origin' | 'destination' | null>(null);
  const [showChat, setShowChat] = useState(false);
  const [loading, setLoading] = useState(false);

  // Ride Details
  const [selectedType, setSelectedType] = useState<'MOTO' | 'CAR'>('MOTO');
  const [tripInfo, setTripInfo] = useState<{distance: string, duration: string} | null>(null);
  
  // New Features (inDrive Style)
  const [notes, setNotes] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<'CASH' | 'PIX'>('PIX');

  // Load Pricing Rules on Mount
  useEffect(() => {
      api.getPricing().then(res => {
          if (res.success) setPricing(res.pricing);
      });
  }, []);

  // Initial location check
  useEffect(() => {
    if (!currentRide && !coords && locationStatus === 'idle') {
      getLocation();
    }
  }, [currentRide]);

  // --- GPS LOGIC ---
  const getLocation = () => {
    setLocationStatus('loading');
    setOriginAddress('📍 Identificando rua exata...'); 
    setOriginSuggestions([]); 
    
    if (!navigator.geolocation) {
      setLocationStatus('error');
      setOriginAddress('');
      alert("Seu GPS está desligado. Por favor, ative a localização.");
      return;
    }

    navigator.geolocation.getCurrentPosition(
      async (position) => {
        const { latitude, longitude } = position.coords;
        setCoords({ lat: latitude, lng: longitude });
        updateUserLocation(latitude, longitude);
        
        try {
          const address = await getAddressFromCoordinates(latitude, longitude);
          setOriginAddress(address);
          setLocationStatus('success');
        } catch (e) {
          console.error("Address fetch error", e);
          setOriginAddress(`Local Detectado (${latitude.toFixed(5)}, ${longitude.toFixed(5)})`);
          setLocationStatus('success');
        }
      },
      (error) => {
        console.error("Error getting location", error);
        setLocationStatus('error');
        setOriginAddress('');
      },
      { 
          enableHighAccuracy: true, 
          timeout: 10000, 
          maximumAge: 0 
      }
    );
  };

  // --- SUGGESTION LOGIC ---
  useEffect(() => {
    if (activeField !== 'origin' || !originAddress || originAddress.length < 3) {
        setOriginSuggestions([]);
        return;
    }
    if (originAddress.includes('Identificando') || originAddress.includes('GPS')) return;

    const timer = setTimeout(async () => {
        setIsSearchingOrigin(true);
        const results = await getPlaceSuggestions(originAddress);
        setOriginSuggestions(results);
        setIsSearchingOrigin(false);
    }, 600);

    return () => clearTimeout(timer);
  }, [originAddress, activeField]);

  useEffect(() => {
    if (activeField !== 'destination' || !destination || destination.length < 3) {
        setDestSuggestions([]);
        return;
    }
    const timer = setTimeout(async () => {
        setIsSearchingDest(true);
        const results = await getPlaceSuggestions(destination);
        setDestSuggestions(results);
        setIsSearchingDest(false);
    }, 600);

    return () => clearTimeout(timer);
  }, [destination, activeField]);


  // --- HANDLERS ---
  const handleSelectOrigin = async (place: PlaceSuggestion) => {
    setOriginAddress(place.name);
    setOriginSuggestions([]);
    setActiveField(null);
    setLocationStatus('idle'); 
    
    if (place.lat && place.lng) {
        const newCoords = { lat: place.lat, lng: place.lng };
        setCoords(newCoords);
        updateUserLocation(place.lat, place.lng);
        if (destination) calculateTrip(newCoords, destCoords);
    }
  };

  const handleSelectDest = async (place: PlaceSuggestion) => {
    setDestination(place.name);
    setDestSuggestions([]);
    setActiveField(null);
    setTripInfo(null);
    
    let newDestCoords = null;
    if (place.lat && place.lng) {
        newDestCoords = { lat: place.lat, lng: place.lng };
        setDestCoords(newDestCoords);
    }
    
    if (originAddress) calculateTrip(coords, newDestCoords);
  };

  const setQuickDestination = (dest: string) => {
     setDestination(dest);
     setTripInfo(null);
     calculateTrip(coords, null); 
  }
  
  const calculateTrip = async (originLoc: {lat: number, lng: number} | null, destLoc: {lat: number, lng: number} | null) => {
     setLoading(true);
     try {
        const details = await estimateTripDetails(
            originAddress, 
            destination, 
            originLoc || undefined, 
            destLoc || undefined
        );
        setTripInfo(details);
     } catch (e) {
        // AI Fallback
        setTripInfo({ distance: 'Calc...', duration: '...' });
     }
     setLoading(false);
  };

  const clearOrigin = () => {
    setOriginAddress('');
    setCoords(null);
    setOriginSuggestions([]);
    setActiveField(null);
    setTripInfo(null);
  };

  const clearDest = () => {
      setDestination('');
      setDestCoords(null);
      setDestSuggestions([]);
      setActiveField(null);
      setTripInfo(null);
  };
  
  // CALCULADORA DE PREÇO DINÂMICO
  const calculateDynamicPrice = (type: 'MOTO' | 'CAR', distStr?: string) => {
      if (!pricing) return type === 'MOTO' ? 4.50 : 7.00; // Fallback hardcoded
      
      const rule = type === 'MOTO' ? pricing.moto : pricing.car;
      
      let distanceKm = 0;
      if (distStr) {
          // Extrai numero da string "5.2 km"
          const match = distStr.match(/[\d\.]+/);
          if (match) distanceKm = parseFloat(match[0]);
      }
      
      const finalPrice = rule.basePrice + (distanceKm * rule.pricePerKm);
      return Math.round(finalPrice * 100) / 100; // Arredonda 2 casas
  };

  const handleSubmit = async () => {
      if (!originAddress || !destination) return;
      
      setLoading(true);
      
      let finalTripInfo = tripInfo;
      if (!finalTripInfo) {
          try {
             finalTripInfo = await estimateTripDetails(originAddress, destination, coords || undefined, destCoords || undefined);
          } catch(e) {
             finalTripInfo = { distance: '---', duration: '---' };
          }
      }
      
      const calculatedPrice = calculateDynamicPrice(selectedType, finalTripInfo?.distance);
      
      requestRide({
          origin: originAddress,
          originLat: coords?.lat,
          originLng: coords?.lng,
          destination: destination,
          destLat: destCoords?.lat,
          destLng: destCoords?.lng,
          price: calculatedPrice,
          type: selectedType,
          distanceFormatted: finalTripInfo?.distance || '---',
          paymentMethod,
          notes: notes || undefined
      });
      setLoading(false);
  };

  // Preço de exibição para UI
  const displayPriceMoto = calculateDynamicPrice('MOTO', tripInfo?.distance);
  const displayPriceCar = calculateDynamicPrice('CAR', tripInfo?.distance);


  // --- RENDER STATES ---

  if (currentRide) {
      // Waiting / Active State
      const isAccepted = currentRide.status === RideStatus.ACCEPTED;
      const isInProgress = currentRide.status === RideStatus.IN_PROGRESS;
      
      return (
        <div className="bg-white/95 dark:bg-slate-800/95 backdrop-blur-xl rounded-3xl p-6 shadow-2xl border border-gray-200 dark:border-slate-700 animate-slide-up mx-4 transition-colors duration-300">
           {/* Status Header */}
           <div className="flex items-center justify-between mb-6">
               <div>
                   <h2 className="text-xl font-bold text-slate-800 dark:text-white">
                       {currentRide.status === RideStatus.PENDING && 'Procurando motorista...'}
                       {isAccepted && 'Motorista a caminho!'}
                       {isInProgress && 'Em viagem'}
                   </h2>
                   <p className="text-slate-500 dark:text-slate-400 text-xs">
                       {currentRide.status === RideStatus.PENDING && 'Aguarde, conectando ao melhor parceiro.'}
                       {isAccepted && 'Ele chegará em breve.'}
                       {isInProgress && 'Relaxe e aproveite o trajeto.'}
                   </p>
               </div>
               <div className="w-12 h-12 bg-gray-100 dark:bg-slate-700 rounded-full flex items-center justify-center animate-pulse">
                   <span className="text-2xl">{currentRide.type === 'MOTO' ? '🛵' : '🚗'}</span>
               </div>
           </div>

           {/* Ride Info */}
           <div className="space-y-4 mb-6">
               <div className="flex items-start gap-3 relative">
                   <div className="flex flex-col items-center mt-1">
                       <div className="w-3 h-3 bg-green-500 rounded-full shadow-[0_0_10px_rgba(34,197,94,0.5)]"></div>
                       <div className="w-0.5 h-full bg-gray-300 dark:bg-slate-600 min-h-[30px]"></div>
                   </div>
                   <div className="pb-4 border-b border-gray-200 dark:border-slate-700/50 w-full">
                       <p className="text-[10px] font-bold text-slate-500 uppercase">Embarque</p>
                       <p className="text-slate-800 dark:text-white text-sm font-medium">{currentRide.origin}</p>
                   </div>
               </div>
               <div className="flex items-start gap-3">
                   <div className="w-3 h-3 bg-red-500 rounded-full shadow-[0_0_10px_rgba(239,68,68,0.5)] mt-1"></div>
                   <div>
                       <p className="text-[10px] font-bold text-slate-500 uppercase">Destino</p>
                       <p className="text-slate-800 dark:text-white text-sm font-medium">{currentRide.destination}</p>
                   </div>
               </div>
           </div>
           
           {/* Actions */}
           <div className="space-y-3">
               {isAccepted && (
                   <button 
                     onClick={() => setShowChat(!showChat)}
                     className="w-full bg-slate-200 dark:bg-slate-700 hover:bg-slate-300 dark:hover:bg-slate-600 text-slate-800 dark:text-white font-bold py-3 rounded-xl transition-colors flex items-center justify-center gap-2"
                   >
                       <span>💬</span> {showChat ? 'Ocultar Chat' : 'Abrir Chat'}
                   </button>
               )}
               
               {showChat && isAccepted && (
                   <div className="h-64 mb-4 animate-fade-in">
                       <ChatWindow />
                   </div>
               )}

               {currentRide.status === RideStatus.PENDING && (
                   <button 
                     onClick={cancelRide}
                     className="w-full bg-red-100 hover:bg-red-200 dark:bg-red-500/10 dark:hover:bg-red-500/20 text-red-600 dark:text-red-500 border border-red-200 dark:border-red-500/50 font-bold py-3 rounded-xl transition-colors"
                   >
                       Cancelar Solicitação
                   </button>
               )}
           </div>
        </div>
      );
  }

  // Request Form
  return (
    <div className="bg-white/95 dark:bg-slate-800/95 backdrop-blur-xl rounded-3xl shadow-[0_20px_50px_rgba(0,0,0,0.1)] dark:shadow-[0_20px_50px_rgba(0,0,0,0.5)] border border-gray-200 dark:border-slate-700 overflow-hidden mx-2 sm:mx-0 transition-colors duration-300">
      <div className="p-5 space-y-4">
        
        {/* Origin Input */}
        <div className="relative z-50"> 
            <div className={`flex items-center bg-gray-50 dark:bg-slate-900 border transition-all rounded-xl px-3 py-3 ${activeField === 'origin' ? 'border-green-500 ring-1 ring-green-500/50' : 'border-gray-200 dark:border-slate-700'}`}>
                <div className={`w-2 h-2 rounded-full mr-3 ${locationStatus === 'success' ? 'bg-green-500 animate-pulse' : 'bg-slate-400 dark:bg-slate-500'}`}></div>
                <input 
                    type="text" 
                    placeholder="De onde vamos sair?"
                    value={originAddress}
                    onChange={(e) => setOriginAddress(e.target.value)}
                    onFocus={() => setActiveField('origin')}
                    className="bg-transparent w-full text-slate-800 dark:text-white text-sm font-medium outline-none placeholder:text-slate-500"
                />
                {originAddress && (
                    <button onClick={clearOrigin} className="text-slate-400 hover:text-slate-600 dark:text-slate-500 dark:hover:text-white p-1">✕</button>
                )}
                <button onClick={getLocation} className="ml-2 text-slate-400 hover:text-green-600 dark:hover:text-green-400 p-1 transition-colors">
                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"></path><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"></path></svg>
                </button>
            </div>

            {/* Origin Suggestions Dropdown */}
            {activeField === 'origin' && (originSuggestions.length > 0 || isSearchingOrigin) && (
                <div className="absolute top-full left-0 right-0 mt-2 bg-white dark:bg-slate-800 border border-gray-200 dark:border-slate-700 rounded-xl shadow-2xl overflow-hidden max-h-60 overflow-y-auto">
                    {isSearchingOrigin && <div className="p-3 text-xs text-slate-500 dark:text-slate-400 text-center">IA buscando endereços...</div>}
                    {originSuggestions.map((place, idx) => (
                        <button 
                            key={idx}
                            onMouseDown={(e) => { e.preventDefault(); handleSelectOrigin(place); }} 
                            className="w-full text-left px-4 py-3 hover:bg-gray-100 dark:hover:bg-slate-700 border-b border-gray-200 dark:border-slate-700/50 last:border-0 flex items-start gap-3 transition-colors"
                        >
                            <span className="text-lg mt-0.5">📍</span>
                            <div>
                                <p className="text-slate-800 dark:text-white text-sm font-bold">{place.name}</p>
                                <p className="text-slate-500 dark:text-slate-400 text-xs">{place.address}</p>
                            </div>
                        </button>
                    ))}
                </div>
            )}
        </div>

        {/* Destination Input */}
        <div className="relative z-40"> 
            <div className={`flex items-center bg-gray-50 dark:bg-slate-900 border transition-all rounded-xl px-3 py-3 ${activeField === 'destination' ? 'border-green-500 ring-1 ring-green-500/50' : 'border-gray-200 dark:border-slate-700'}`}>
                <div className="w-2 h-2 bg-red-500 rounded-sm mr-3"></div>
                <input 
                    type="text" 
                    placeholder="Para onde vamos?"
                    value={destination}
                    onChange={(e) => setDestination(e.target.value)}
                    onFocus={() => setActiveField('destination')}
                    className="bg-transparent w-full text-slate-800 dark:text-white text-sm font-medium outline-none placeholder:text-slate-500"
                />
                {destination && (
                    <button onClick={clearDest} className="text-slate-400 hover:text-slate-600 dark:text-slate-500 dark:hover:text-white p-1">✕</button>
                )}
            </div>

            {/* Destination Suggestions Dropdown */}
            {activeField === 'destination' && (destSuggestions.length > 0 || isSearchingDest) && (
                <div className="absolute top-full left-0 right-0 mt-2 bg-white dark:bg-slate-800 border border-gray-200 dark:border-slate-700 rounded-xl shadow-2xl overflow-hidden max-h-60 overflow-y-auto z-50">
                    {isSearchingDest && <div className="p-3 text-xs text-slate-500 dark:text-slate-400 text-center">IA buscando locais...</div>}
                    {destSuggestions.map((place, idx) => (
                        <button 
                            key={idx}
                            onMouseDown={(e) => { e.preventDefault(); handleSelectDest(place); }}
                            className="w-full text-left px-4 py-3 hover:bg-gray-100 dark:hover:bg-slate-700 border-b border-gray-200 dark:border-slate-700/50 last:border-0 flex items-start gap-3 transition-colors"
                        >
                            <span className="text-lg mt-0.5">🏁</span>
                            <div>
                                <p className="text-slate-800 dark:text-white text-sm font-bold">{place.name}</p>
                                <p className="text-slate-500 dark:text-slate-400 text-xs">{place.address}</p>
                            </div>
                        </button>
                    ))}
                </div>
            )}
        </div>

        {/* Quick Access */}
        <div className="flex gap-2 overflow-x-auto pb-1 no-scrollbar z-30 relative">
            <button onClick={() => setQuickDestination("Casa")} className="flex items-center gap-1 bg-slate-200 hover:bg-slate-300 dark:bg-slate-700 dark:hover:bg-slate-600 px-3 py-1.5 rounded-lg text-xs font-medium text-slate-700 dark:text-slate-300 transition-colors whitespace-nowrap">
                🏠 Casa
            </button>
            <button onClick={() => setQuickDestination("Trabalho")} className="flex items-center gap-1 bg-slate-200 hover:bg-slate-300 dark:bg-slate-700 dark:hover:bg-slate-600 px-3 py-1.5 rounded-lg text-xs font-medium text-slate-700 dark:text-slate-300 transition-colors whitespace-nowrap">
                💼 Trabalho
            </button>
            <button onClick={() => setQuickDestination("Feira do Aleixo")} className="flex items-center gap-1 bg-slate-200 hover:bg-slate-300 dark:bg-slate-700 dark:hover:bg-slate-600 px-3 py-1.5 rounded-lg text-xs font-medium text-slate-700 dark:text-slate-300 transition-colors whitespace-nowrap">
                🛒 Feira
            </button>
        </div>
        
        {/* Vehicle Selection */}
        <div className="grid grid-cols-2 gap-3 pt-2">
            <button 
                onClick={() => setSelectedType('MOTO')}
                className={`relative p-3 rounded-xl border-2 transition-all flex flex-col items-start ${selectedType === 'MOTO' ? 'bg-green-100 border-green-500 dark:bg-green-500/10' : 'bg-gray-50 border-gray-200 hover:border-gray-300 dark:bg-slate-900 dark:border-slate-700 dark:hover:border-slate-600'}`}
            >
                {selectedType === 'MOTO' && <div className="absolute top-2 right-2 w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>}
                <span className="text-2xl mb-1">🛵</span>
                <span className="text-sm font-bold text-slate-800 dark:text-white">Moto</span>
                <span className="text-green-600 dark:text-green-400 font-black text-xs">R$ {displayPriceMoto.toFixed(2)}</span>
            </button>

            <button 
                onClick={() => setSelectedType('CAR')}
                className={`relative p-3 rounded-xl border-2 transition-all flex flex-col items-start ${selectedType === 'CAR' ? 'bg-green-100 border-green-500 dark:bg-green-500/10' : 'bg-gray-50 border-gray-200 hover:border-gray-300 dark:bg-slate-900 dark:border-slate-700 dark:hover:border-slate-600'}`}
            >
                 {selectedType === 'CAR' && <div className="absolute top-2 right-2 w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>}
                <span className="text-2xl mb-1">🚗</span>
                <span className="text-sm font-bold text-slate-800 dark:text-white">Carro</span>
                <span className="text-green-600 dark:text-green-400 font-black text-xs">R$ {displayPriceCar.toFixed(2)}</span>
            </button>
        </div>
        
        {/* Extras: Payment & Notes */}
        <div className="grid grid-cols-2 gap-3">
             <div className="bg-gray-50 dark:bg-slate-900 rounded-xl p-1 flex border border-gray-200 dark:border-slate-700">
                 <button onClick={() => setPaymentMethod('PIX')} className={`flex-1 rounded-lg text-[10px] font-bold py-2 ${paymentMethod === 'PIX' ? 'bg-slate-200 text-slate-900 dark:bg-slate-700 dark:text-white' : 'text-slate-400'}`}>
                    💠 PIX
                 </button>
                 <button onClick={() => setPaymentMethod('CASH')} className={`flex-1 rounded-lg text-[10px] font-bold py-2 ${paymentMethod === 'CASH' ? 'bg-slate-200 text-slate-900 dark:bg-slate-700 dark:text-white' : 'text-slate-400'}`}>
                    💵 DINHEIRO
                 </button>
             </div>
             
             <input 
                type="text" 
                placeholder="Obs: Troco p/ 20..."
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                className="bg-gray-50 dark:bg-slate-900 border border-gray-200 dark:border-slate-700 rounded-xl px-3 text-xs text-slate-800 dark:text-white outline-none focus:border-slate-500"
             />
        </div>

        {/* Submit Button */}
        <button 
            onClick={handleSubmit}
            disabled={!originAddress || !destination || loading}
            className={`w-full py-4 rounded-xl font-black text-lg uppercase tracking-wide shadow-lg transition-all transform active:scale-95 ${
                !originAddress || !destination || loading
                ? 'bg-gray-300 text-gray-500 dark:bg-slate-700 dark:text-slate-500 cursor-not-allowed'
                : 'bg-green-500 hover:bg-green-400 text-slate-900 hover:shadow-green-500/20'
            }`}
        >
            {loading ? (
                <div className="flex items-center justify-center gap-2">
                    <div className="w-5 h-5 border-2 border-slate-800 border-t-transparent rounded-full animate-spin"></div>
                    <span>Calculando...</span>
                </div>
            ) : (
                <>CHAMAR AGORA</>
            )}
        </button>
        
        {/* Trip Info Display */}
        {tripInfo && !loading && (
             <div className="flex justify-between items-center text-[10px] text-slate-500 font-bold px-2 uppercase tracking-wider">
                 <span>Distância: {tripInfo.distance}</span>
                 <span>Tempo est: {tripInfo.duration}</span>
             </div>
        )}

      </div>
    </div>
  );
};

export default RideRequest;
