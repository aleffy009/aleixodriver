import React, { useState, useEffect, useRef } from 'react';
import { useRide } from '../contexts/RideContext';
import { useAuth } from '../contexts/AuthContext';
import { UserRole } from '../types';

const QUICK_REPLIES_PASSENGER = [
    "Estou aqui!",
    "Estou a caminho.",
    "Qual a cor do veículo?",
    "Aguarde um pouco, por favor."
];

const QUICK_REPLIES_DRIVER = [
    "Cheguei ao local!",
    "Estou a caminho.",
    "Trânsito intenso, já chego.",
    "Não estou encontrando o número."
];

const ChatWindow = () => {
  const { messages, sendMessage, notifyTyping, isPeerTyping } = useRide();
  const { user } = useAuth();
  const [inputText, setInputText] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const typingTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isPeerTyping]);

  const handleSend = (text: string) => {
    if (!text.trim() || !user) return;
    sendMessage(user.id, text);
    setInputText('');
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      setInputText(e.target.value);
      
      // Throttle typing notification (envia a cada 2s máx)
      if (!typingTimerRef.current) {
          notifyTyping();
          typingTimerRef.current = setTimeout(() => {
              typingTimerRef.current = null;
          }, 2000);
      }
  };

  const quickReplies = user?.role === UserRole.DRIVER ? QUICK_REPLIES_DRIVER : QUICK_REPLIES_PASSENGER;
  const peerName = user?.role === UserRole.DRIVER ? 'Passageiro' : 'Motorista';

  return (
    <div className="flex flex-col h-full bg-slate-900 rounded-xl overflow-hidden border border-slate-700 shadow-lg">
      {/* Header */}
      <div className="bg-slate-800 p-3 border-b border-slate-700 flex items-center justify-between">
        <div className="flex items-center gap-2">
            <div className={`w-2 h-2 rounded-full ${isPeerTyping ? 'bg-green-400 animate-ping' : 'bg-green-600'}`}></div>
            <div className="flex flex-col">
                <span className="text-sm font-bold text-white">Chat com {peerName}</span>
                {isPeerTyping && <span className="text-[10px] text-green-400 animate-pulse">digitando...</span>}
            </div>
        </div>
      </div>

      {/* Messages Area */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3 bg-slate-900/50 min-h-[200px] max-h-[300px]">
        {messages.length === 0 && (
            <div className="text-center text-slate-500 text-xs mt-4">
                Inicie a conversa com segurança.
            </div>
        )}
        
        {messages.map((msg) => {
            const isMe = msg.senderId === user?.id;
            if (msg.isSystem) {
                return (
                    <div key={msg.id} className="flex justify-center my-2">
                        <span className="text-[10px] bg-slate-800 text-slate-400 px-2 py-1 rounded-full uppercase tracking-wider">
                            {msg.text}
                        </span>
                    </div>
                );
            }
            return (
                <div key={msg.id} className={`flex ${isMe ? 'justify-end' : 'justify-start'}`}>
                    <div className={`max-w-[80%] rounded-xl px-3 py-2 text-sm ${
                        isMe 
                        ? 'bg-green-600 text-white rounded-tr-none' 
                        : 'bg-slate-700 text-slate-200 rounded-tl-none'
                    }`}>
                        {msg.text}
                        <div className={`text-[9px] mt-1 text-right opacity-70 ${isMe ? 'text-green-200' : 'text-slate-400'}`}>
                            {new Date(msg.timestamp).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                        </div>
                    </div>
                </div>
            );
        })}

        {/* Real-time Typing Indicator */}
        {isPeerTyping && (
            <div className="flex justify-start animate-fade-in">
                <div className="bg-slate-700 text-slate-200 rounded-xl rounded-tl-none px-4 py-3 flex items-center gap-1 h-[38px]">
                    <div className="w-1.5 h-1.5 bg-slate-400 rounded-full animate-bounce [animation-delay:-0.3s]"></div>
                    <div className="w-1.5 h-1.5 bg-slate-400 rounded-full animate-bounce [animation-delay:-0.15s]"></div>
                    <div className="w-1.5 h-1.5 bg-slate-400 rounded-full animate-bounce"></div>
                </div>
            </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Quick Replies */}
      <div className="px-2 pt-2 pb-1 bg-slate-800 overflow-x-auto flex gap-2 no-scrollbar">
         {quickReplies.map((reply, idx) => (
             <button 
                key={idx}
                onClick={() => handleSend(reply)}
                className="whitespace-nowrap px-3 py-1 bg-slate-700 hover:bg-slate-600 text-slate-300 text-xs rounded-full border border-slate-600 transition-colors"
             >
                {reply}
             </button>
         ))}
      </div>

      {/* Input Area */}
      <div className="p-2 bg-slate-800 border-t border-slate-700 flex gap-2">
        <input 
            type="text" 
            value={inputText}
            onChange={handleInputChange}
            onKeyDown={(e) => e.key === 'Enter' && handleSend(inputText)}
            placeholder="Digite sua mensagem..."
            className="flex-1 bg-slate-900 border border-slate-600 text-white text-sm rounded-full px-4 py-2 focus:ring-1 focus:ring-green-500 outline-none"
        />
        <button 
            onClick={() => handleSend(inputText)}
            disabled={!inputText.trim()}
            className="bg-green-500 hover:bg-green-600 disabled:opacity-50 disabled:cursor-not-allowed text-slate-900 rounded-full p-2 transition-colors"
        >
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5">
                <path d="M3.478 2.404a.75.75 0 0 0-.926.941l2.432 7.905H13.5a.75.75 0 0 1 0 1.5H4.984l-2.432 7.905a.75.75 0 0 0 .926.94 60.519 60.519 0 0 0 18.445-8.986.75.75 0 0 0 0-1.218A60.517 60.517 0 0 0 3.478 2.404Z" />
            </svg>
        </button>
      </div>
    </div>
  );
};

export default ChatWindow;