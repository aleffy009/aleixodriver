
import React, { useState, useRef } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useRide } from '../contexts/RideContext';
import { useToast } from '../contexts/ToastContext'; // Importado
import { UserRole } from '../types';
import RechargeModal from './RechargeModal';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  defaultTab?: 'profile' | 'settings' | 'history';
}

const SettingsModal: React.FC<SettingsModalProps> = ({ isOpen, onClose, defaultTab = 'profile' }) => {
  const { user, updateProfile, logout } = useAuth();
  const { allRides } = useRide();
  const { addToast } = useToast(); // Hook
  
  const [activeTab, setActiveTab] = useState<'profile' | 'settings' | 'history'>(defaultTab);
  const [isLoading, setIsLoading] = useState(false);
  const [showRecharge, setShowRecharge] = useState(false);
  
  // Form State
  const [name, setName] = useState(user?.name || '');
  const [phone, setPhone] = useState(user?.phone || '');
  const [vehiclePlate, setVehiclePlate] = useState(user?.vehiclePlate || '');
  const [vehicleType, setVehicleType] = useState(user?.vehicleType || 'CAR');
  
  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen || !user) return null;

  const completedRides = allRides.filter(r => 
      r.status === 'COMPLETED' && 
      (r.driverId === user.id || r.passengerId === user.id)
  );

  const handleSaveProfile = async () => {
      setIsLoading(true);
      await new Promise(r => setTimeout(r, 1000));
      
      await updateProfile({
          name,
          phone,
          vehiclePlate: user.role === UserRole.DRIVER ? vehiclePlate : undefined,
          vehicleType: user.role === UserRole.DRIVER ? vehicleType as 'CAR' | 'MOTO' : undefined
      });
      
      addToast("Perfil atualizado com sucesso!", 'success');
      setIsLoading(false);
      onClose();
  };

  const compressImage = (file: File): Promise<string> => {
      return new Promise((resolve, reject) => {
          if (!file.type.startsWith('image/')) {
              reject(new Error("O arquivo selecionado não é uma imagem válida."));
              return;
          }

          const reader = new FileReader();
          reader.readAsDataURL(file);
          reader.onload = (event) => {
              const img = new Image();
              img.src = event.target?.result as string;
              img.onload = () => {
                  const canvas = document.createElement('canvas');
                  const ctx = canvas.getContext('2d');
                  if (!ctx) {
                      reject(new Error("Erro ao processar imagem."));
                      return;
                  }
                  const MAX_WIDTH = 400;
                  let newWidth = img.width;
                  let newHeight = img.height;

                  if (img.width > MAX_WIDTH) {
                      const scaleSize = MAX_WIDTH / img.width;
                      newWidth = MAX_WIDTH;
                      newHeight = img.height * scaleSize;
                  }

                  canvas.width = newWidth;
                  canvas.height = newHeight;
                  ctx.drawImage(img, 0, 0, newWidth, newHeight);
                  const compressedBase64 = canvas.toDataURL('image/jpeg', 0.6);
                  resolve(compressedBase64);
              };
              img.onerror = () => reject(new Error("Erro ao carregar os dados da imagem."));
          };
          reader.onerror = () => reject(new Error("Erro ao ler o arquivo."));
      });
  };

  const handlePhotoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if (e.target) e.target.value = '';

      if (file) {
          setIsLoading(true);
          try {
              const compressedBase64 = await compressImage(file);
              await updateProfile({ photoUrl: compressedBase64 });
              addToast("Foto de perfil atualizada!", 'success');
          } catch (error: any) {
              addToast(error.message || "Erro ao carregar imagem.", 'error');
          } finally {
              setIsLoading(false);
          }
      }
  };

  const handleLogout = () => {
      if (window.confirm("Deseja realmente sair?")) {
          onClose();
          logout();
      }
  };

  return (
    <>
    <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 animate-fade-in">
      <div className="absolute inset-0 bg-slate-900/80 backdrop-blur-sm" onClick={onClose}></div>
      
      <div className="bg-slate-800 w-full max-w-lg rounded-2xl shadow-2xl border border-slate-700 relative z-10 overflow-hidden flex flex-col max-h-[85vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-700 bg-slate-800/50 shrink-0">
            <h2 className="text-xl font-bold text-white">
                {user.role === UserRole.DRIVER ? 'Central do Motorista' : 'Minha Conta'}
            </h2>
            <button onClick={onClose} className="p-2 text-slate-400 hover:text-white rounded-full hover:bg-slate-700">✕</button>
        </div>

        {/* Tabs */}
        <div className="flex border-b border-slate-700 shrink-0 overflow-x-auto">
            <button 
                onClick={() => setActiveTab('profile')}
                className={`flex-1 py-3 px-4 text-sm font-medium transition-colors whitespace-nowrap ${activeTab === 'profile' ? 'text-green-400 border-b-2 border-green-400 bg-green-400/5' : 'text-slate-400 hover:text-white'}`}
            >
                Perfil
            </button>
            <button 
                onClick={() => setActiveTab('history')}
                className={`flex-1 py-3 px-4 text-sm font-medium transition-colors whitespace-nowrap ${activeTab === 'history' ? 'text-green-400 border-b-2 border-green-400 bg-green-400/5' : 'text-slate-400 hover:text-white'}`}
            >
                Histórico
            </button>
            <button 
                onClick={() => setActiveTab('settings')}
                className={`flex-1 py-3 px-4 text-sm font-medium transition-colors whitespace-nowrap ${activeTab === 'settings' ? 'text-green-400 border-b-2 border-green-400 bg-green-400/5' : 'text-slate-400 hover:text-white'}`}
            >
                Config
            </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto custom-scrollbar">
            {activeTab === 'profile' && (
                <div className="space-y-6">
                    {/* Photo Section */}
                    <div className="flex flex-col items-center">
                        <div className="relative group cursor-pointer" onClick={() => !isLoading && fileInputRef.current?.click()}>
                            <div className={`w-24 h-24 rounded-full p-[2px] shadow-lg transition-all ${user.photoUrl ? 'bg-green-500' : 'bg-slate-600'}`}>
                                <div className="w-full h-full rounded-full bg-slate-800 flex items-center justify-center overflow-hidden relative">
                                     {isLoading ? (
                                         <div className="w-8 h-8 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                                     ) : user.photoUrl ? (
                                         <img src={user.photoUrl} alt="Profile" className="w-full h-full object-cover" />
                                     ) : (
                                         <span className="text-3xl font-bold text-white">{name.charAt(0).toUpperCase()}</span>
                                     )}
                                     
                                     {!isLoading && (
                                         <div className="absolute inset-0 bg-black/50 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                                             <span className="text-xs text-white font-medium">Alterar</span>
                                         </div>
                                     )}
                                </div>
                            </div>
                            <div className="absolute bottom-0 right-0 bg-slate-700 rounded-full p-1.5 border border-slate-800 text-white shadow-sm">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" className="w-3 h-3">
                                    <path d="m5.433 13.917 1.262-3.155A4 4 0 0 1 7.58 9.42l6.92-6.918a2.121 2.121 0 0 1 3 3l-6.92 6.918c-.383.383-.84.685-1.343.886l-3.154 1.262a.5.5 0 0 1-.65-.65Z" />
                                    <path d="M3.5 5.75c0-.69.56-1.25 1.25-1.25H10A.75.75 0 0 0 10 3H4.75A2.75 2.75 0 0 0 2 5.75v9.5A2.75 2.75 0 0 0 4.75 18h9.5A2.75 2.75 0 0 0 17 15.25V10a.75.75 0 0 0-1.5 0v5.25c0 .69-.56 1.25-1.25 1.25h-9.5c-.69 0-1.25-.56-1.25-1.25v-9.5Z" />
                                </svg>
                            </div>
                        </div>
                        <input type="file" ref={fileInputRef} className="hidden" accept="image/*" onChange={handlePhotoUpload} />
                        <p className={`text-xs mt-2 font-bold ${user.photoUrl ? 'text-slate-400' : 'text-slate-400'}`}>
                            {user.photoUrl ? 'Toque para alterar' : 'Toque para adicionar foto'}
                        </p>
                    </div>

                    <div className="space-y-4">
                        <div>
                            <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Nome Completo</label>
                            <input 
                                type="text" 
                                value={name}
                                onChange={(e) => setName(e.target.value)}
                                className="w-full bg-slate-900 border border-slate-600 rounded-lg px-4 py-3 text-white focus:ring-2 focus:ring-green-500/50 outline-none"
                            />
                        </div>
                        <div>
                            <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Telefone / WhatsApp</label>
                            <input 
                                type="text" 
                                value={phone}
                                onChange={(e) => setPhone(e.target.value)}
                                placeholder="(92) 99999-9999"
                                className="w-full bg-slate-900 border border-slate-600 rounded-lg px-4 py-3 text-white focus:ring-2 focus:ring-green-500/50 outline-none"
                            />
                        </div>
                        
                        {user.role === UserRole.DRIVER && (
                            <div className="p-4 bg-slate-900/50 rounded-xl border border-slate-700 space-y-4">
                                <h3 className="text-sm font-bold text-green-400 uppercase">Veículo</h3>
                                <div className="flex gap-3">
                                     <div className="flex-1">
                                        <label className="block text-xs font-bold text-slate-500 mb-1">Tipo</label>
                                        <select 
                                            value={vehicleType}
                                            onChange={(e) => setVehicleType(e.target.value)}
                                            className="w-full bg-slate-800 border border-slate-600 rounded-lg px-3 py-2 text-white"
                                        >
                                            <option value="CAR">Carro</option>
                                            <option value="MOTO">Moto</option>
                                        </select>
                                     </div>
                                     <div className="flex-1">
                                        <label className="block text-xs font-bold text-slate-500 mb-1">Placa</label>
                                        <input 
                                            type="text" 
                                            value={vehiclePlate}
                                            onChange={(e) => setVehiclePlate(e.target.value)}
                                            className="w-full bg-slate-800 border border-slate-600 rounded-lg px-3 py-2 text-white outline-none"
                                        />
                                     </div>
                                </div>
                            </div>
                        )}
                    </div>

                    <div className="pt-2">
                         <button 
                             onClick={handleLogout} 
                             className="w-full text-red-500 hover:text-red-400 text-sm font-bold py-2 border border-red-500/20 hover:border-red-500/50 rounded-lg transition-colors"
                         >
                             Sair da Conta
                         </button>
                    </div>
                </div>
            )}

            {activeTab === 'history' && (
                <div className="space-y-4">
                    {completedRides.length === 0 ? (
                        <div className="text-center py-10 text-slate-500">
                            <p>Nenhuma corrida finalizada ainda.</p>
                        </div>
                    ) : (
                        completedRides.map(ride => (
                            <div key={ride.id} className="bg-slate-900 p-4 rounded-xl border border-slate-700">
                                <div className="flex justify-between items-start mb-2">
                                    <span className="text-xs text-slate-400">{new Date(ride.timestamp).toLocaleDateString()}</span>
                                    <span className="text-green-400 font-bold">R$ {ride.price.toFixed(2)}</span>
                                </div>
                                <div className="space-y-2">
                                    <div className="flex items-center gap-2">
                                        <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                                        <p className="text-xs text-white truncate">{ride.origin}</p>
                                    </div>
                                    <div className="flex items-center gap-2">
                                        <div className="w-2 h-2 bg-red-500 rounded-full"></div>
                                        <p className="text-xs text-white truncate">{ride.destination}</p>
                                    </div>
                                </div>
                            </div>
                        ))
                    )}
                </div>
            )}

            {activeTab === 'settings' && (
                <div className="space-y-4">
                    {user.role === UserRole.DRIVER && (
                        <button 
                             onClick={() => setShowRecharge(true)}
                             className="w-full flex items-center justify-between p-4 bg-purple-600/10 border border-purple-500/30 rounded-lg hover:bg-purple-600/20 transition-colors"
                        >
                            <div className="flex items-center gap-3">
                                <span className="text-xl">⚡</span>
                                <div className="text-left">
                                    <p className="text-purple-400 font-bold">Recarregar Carteira</p>
                                    <p className="text-xs text-slate-400">Adicionar créditos para trabalhar</p>
                                </div>
                            </div>
                            <span className="text-slate-400">→</span>
                        </button>
                    )}

                    <div className="flex items-center justify-between p-4 bg-slate-900 rounded-lg">
                        <div>
                            <p className="text-white font-medium">Notificações de Som</p>
                            <p className="text-xs text-slate-400">Tocar sons ao receber corridas/mensagens</p>
                        </div>
                        <div className="w-10 h-6 bg-green-500 rounded-full relative cursor-pointer">
                            <div className="absolute right-1 top-1 w-4 h-4 bg-white rounded-full shadow"></div>
                        </div>
                    </div>

                    <div className="flex items-center justify-between p-4 bg-slate-900 rounded-lg">
                        <div>
                            <p className="text-white font-medium">Navegação Padrão</p>
                            <p className="text-xs text-slate-400">App preferido para rotas</p>
                        </div>
                        <span className="text-sm text-blue-400 font-bold">Waze</span>
                    </div>
                </div>
            )}
        </div>

        {activeTab === 'profile' && (
            <div className="p-4 border-t border-slate-700 bg-slate-800/50 shrink-0">
                <button 
                    onClick={handleSaveProfile}
                    disabled={isLoading}
                    className="w-full bg-green-500 hover:bg-green-600 text-slate-900 font-bold py-3 rounded-xl transition-all shadow-lg flex items-center justify-center"
                >
                    {isLoading ? <div className="w-5 h-5 border-2 border-slate-900 border-t-transparent rounded-full animate-spin"/> : 'Salvar Alterações'}
                </button>
            </div>
        )}
      </div>
    </div>
    
    <RechargeModal 
        isOpen={showRecharge}
        onClose={() => setShowRecharge(false)}
    />
    </>
  );
};

export default SettingsModal;
