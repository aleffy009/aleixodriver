
import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useRide } from '../contexts/RideContext';
import { UserRole, RechargeOption, User, SystemError, UserStatus, PricingRules } from '../types';
import { api } from '../services/api';
import { useToast } from '../contexts/ToastContext';

const AdminDashboard = () => {
  const { user } = useAuth();
  const { allRides } = useRide();
  const { addToast } = useToast();
  const [activeTab, setActiveTab] = useState<'overview' | 'finance' | 'users' | 'config' | 'logs'>('users');
  
  // Finance State
  const [rechargeOptions, setRechargeOptions] = useState<RechargeOption[]>([]);
  const [loadingOpts, setLoadingOpts] = useState(false);

  // Users Management State
  const [users, setUsers] = useState<User[]>([]);
  const [filteredUsers, setFilteredUsers] = useState<User[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [userFilter, setUserFilter] = useState<'ALL' | 'DRIVER' | 'PASSENGER' | 'PENDING'>('ALL');
  const [loadingUsers, setLoadingUsers] = useState(false);
  const [selectedUser, setSelectedUser] = useState<User | null>(null);
  const [balanceModalUser, setBalanceModalUser] = useState<User | null>(null);
  const [amountToAdd, setAmountToAdd] = useState<string>('');
  
  // Config / Pricing State
  const [pricing, setPricing] = useState<PricingRules | null>(null);
  const [savingConfig, setSavingConfig] = useState(false);

  // Logs State
  const [systemErrors, setSystemErrors] = useState<SystemError[]>([]);

  // Carrega dados iniciais
  useEffect(() => {
      loadData();
      // Auto-refresh users
      const interval = setInterval(() => {
          if (activeTab === 'users') loadUsers();
      }, 5000);
      return () => clearInterval(interval);
  }, [activeTab]);

  const loadData = () => {
      if (activeTab === 'finance') {
          setLoadingOpts(true);
          api.getRechargeOptions().then(res => {
              if (res.success) setRechargeOptions(res.options);
              setLoadingOpts(false);
          });
      }

      if (activeTab === 'users') {
          loadUsers();
      }
      
      if (activeTab === 'config') {
          api.getPricing().then(res => {
              if(res.success) setPricing(res.pricing);
          });
      }
      
      if (activeTab === 'logs') {
          api.getSystemErrors().then(res => {
              if (res.success) setSystemErrors(res.errors);
          });
      }
  };

  const loadUsers = () => {
      setLoadingUsers(true);
      api.getUsers().then(res => {
          if (res.success) {
              setUsers(res.users);
              filterUsersList(res.users, searchTerm, userFilter);
          }
          setLoadingUsers(false);
      });
  };

  const filterUsersList = (list: User[], term: string, roleFilter: string) => {
      let filtered = list;

      // Special Filter for Pending
      if (roleFilter === 'PENDING') {
          filtered = filtered.filter(u => u.role === UserRole.DRIVER && u.status === UserStatus.PENDING);
      } else if (roleFilter !== 'ALL') {
          filtered = filtered.filter(u => u.role === roleFilter && u.status !== UserStatus.PENDING);
      }

      // Filter by Term
      if (term) {
          const lowerTerm = term.toLowerCase();
          filtered = filtered.filter(u => 
              u.name.toLowerCase().includes(lowerTerm) || 
              u.email.toLowerCase().includes(lowerTerm) ||
              (u.cpf && u.cpf.includes(lowerTerm)) ||
              (u.vehiclePlate && u.vehiclePlate.toLowerCase().includes(lowerTerm))
          );
      }

      setFilteredUsers(filtered);
  };

  useEffect(() => {
      filterUsersList(users, searchTerm, userFilter);
  }, [searchTerm, users, userFilter]);

  if (!user || user.role !== UserRole.ADMIN) {
    return (
        <div className="min-h-screen flex items-center justify-center bg-slate-900 text-white">
            <div className="text-center p-8 bg-slate-800 rounded-xl border border-red-500/50">
                <h1 className="text-2xl font-bold text-red-500 mb-2">Acesso Restrito</h1>
                <p>Você não tem permissão para acessar esta área.</p>
                <button onClick={() => window.location.hash = ''} className="mt-4 px-4 py-2 bg-slate-700 rounded hover:bg-slate-600">Voltar</button>
            </div>
        </div>
    );
  }

  // --- HANDLERS ---
  const handleUploadQR = async (id: string, e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if (!file) return;
      
      const reader = new FileReader();
      reader.onloadend = async () => {
          const base64 = reader.result as string;
          setRechargeOptions(prev => prev.map(opt => opt.id === id ? { ...opt, qrCodeUrl: base64 } : opt));
          await api.updateRechargeOption(id, base64);
          addToast("QR Code atualizado com sucesso!", 'success');
      };
      reader.readAsDataURL(file);
  };

  const handleAddBalance = async () => {
      if (!balanceModalUser || !amountToAdd) return;
      
      const val = parseFloat(amountToAdd);
      if (isNaN(val) || val <= 0) {
          addToast("Valor inválido", 'error');
          return;
      }

      const res = await api.addBalance(balanceModalUser.id, val);
      if (res.success) {
          addToast(`Adicionado R$ ${val} para ${balanceModalUser.name}`, 'success');
          setUsers(prev => prev.map(u => u.id === balanceModalUser.id ? { ...u, balance: (u.balance || 0) + val } : u));
          setBalanceModalUser(null);
          setAmountToAdd('');
      } else {
          addToast("Erro ao adicionar saldo", 'error');
      }
  };

  const handleApprove = async (u: User) => {
      if(window.confirm(`Aprovar ${u.name}?`)) {
          const res = await api.approveDriver(u.id);
          if(res.success) {
              addToast("Motorista aprovado!", 'success');
              loadUsers();
          }
      }
  };

  const handleReject = async (u: User) => {
      if(window.confirm(`Rejeitar cadastro de ${u.name}?`)) {
          const res = await api.rejectDriver(u.id);
          if(res.success) {
              addToast("Motorista rejeitado.", 'warning');
              loadUsers();
          }
      }
  };

  const handleBan = async (u: User) => {
      const reason = prompt("Motivo do banimento?");
      if(reason) {
          const res = await api.banUser(u.id);
          if(res.success) {
              addToast("Usuário banido.", 'error');
              loadUsers();
              setSelectedUser(null);
          }
      }
  };

  const handleSavePricing = async () => {
      if(!pricing) return;
      setSavingConfig(true);
      const res = await api.updatePricing(pricing);
      if(res.success) {
          addToast("Preços atualizados com sucesso!", 'success');
      } else {
          addToast("Erro ao atualizar preços.", 'error');
      }
      setSavingConfig(false);
  };

  const totalRides = allRides.length;
  const totalRevenue = allRides.reduce((acc, curr) => acc + curr.price, 0);

  return (
    <div className="min-h-screen bg-slate-900 p-4 sm:p-6 pb-24 font-sans text-slate-100">
      <div className="max-w-7xl mx-auto">
        {/* HEADER */}
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-8 gap-4 bg-slate-800 p-6 rounded-2xl border border-slate-700 shadow-lg">
            <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-green-500 rounded-xl flex items-center justify-center text-2xl shadow-lg">🛡️</div>
                <div>
                    <h1 className="text-2xl font-bold text-white">Painel Administrativo</h1>
                    <p className="text-slate-400 text-sm">Controle total do sistema AleixoDrive</p>
                </div>
            </div>
            <div className="flex gap-2">
                 <button onClick={() => window.location.hash = ''} className="px-4 py-2 bg-slate-700 hover:bg-slate-600 rounded-lg text-sm font-bold transition-colors">Voltar ao App</button>
            </div>
        </div>

        {/* TABS */}
        <div className="flex gap-2 sm:gap-4 mb-6 overflow-x-auto pb-2 no-scrollbar">
            <button onClick={() => setActiveTab('users')} className={`flex items-center gap-2 px-5 py-3 font-bold rounded-xl transition-all whitespace-nowrap ${activeTab === 'users' ? 'bg-blue-600 text-white shadow-lg shadow-blue-500/20' : 'bg-slate-800 text-slate-400 hover:bg-slate-700'}`}>
                <span>👥</span> Usuários
            </button>
            <button onClick={() => setActiveTab('finance')} className={`flex items-center gap-2 px-5 py-3 font-bold rounded-xl transition-all whitespace-nowrap ${activeTab === 'finance' ? 'bg-green-600 text-white shadow-lg shadow-green-500/20' : 'bg-slate-800 text-slate-400 hover:bg-slate-700'}`}>
                <span>💰</span> Financeiro
            </button>
            <button onClick={() => setActiveTab('config')} className={`flex items-center gap-2 px-5 py-3 font-bold rounded-xl transition-all whitespace-nowrap ${activeTab === 'config' ? 'bg-orange-500 text-white shadow-lg shadow-orange-500/20' : 'bg-slate-800 text-slate-400 hover:bg-slate-700'}`}>
                <span>⚙️</span> Configurações
            </button>
            <button onClick={() => setActiveTab('overview')} className={`flex items-center gap-2 px-5 py-3 font-bold rounded-xl transition-all whitespace-nowrap ${activeTab === 'overview' ? 'bg-purple-600 text-white shadow-lg shadow-purple-500/20' : 'bg-slate-800 text-slate-400 hover:bg-slate-700'}`}>
                <span>📊</span> Relatórios
            </button>
            <button onClick={() => setActiveTab('logs')} className={`flex items-center gap-2 px-5 py-3 font-bold rounded-xl transition-all whitespace-nowrap ${activeTab === 'logs' ? 'bg-red-500/20 text-red-400 border border-red-500/50' : 'bg-slate-800 text-slate-400 hover:bg-slate-700'}`}>
                <span>🤖</span> Erros IA
            </button>
        </div>

        {/* --- CONFIG TAB (PRICING) --- */}
        {activeTab === 'config' && pricing && (
            <div className="bg-slate-800 rounded-2xl border border-slate-700 p-8 shadow-2xl animate-fade-in max-w-5xl mx-auto">
                <h2 className="text-2xl font-bold text-white mb-6 flex items-center gap-3">
                    <span className="text-orange-400">🏷️</span> Tabela de Preços e Taxas
                </h2>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    {/* Moto Config */}
                    <div className="bg-slate-900 p-6 rounded-2xl border border-slate-700 relative overflow-hidden">
                        <div className="absolute top-0 right-0 p-4 opacity-10 text-6xl">🛵</div>
                        <h3 className="text-xl font-bold text-green-400 mb-4 flex items-center gap-2">
                             🛵 Moto
                        </h3>
                        <div className="space-y-4">
                            <div>
                                <label className="block text-slate-400 text-sm font-bold mb-1">Preço Base (Taxa Fixa)</label>
                                <div className="relative">
                                    <span className="absolute left-3 top-3 text-slate-500">R$</span>
                                    <input 
                                        type="number" 
                                        step="0.10"
                                        value={pricing.moto.basePrice}
                                        onChange={(e) => setPricing({...pricing, moto: {...pricing.moto, basePrice: parseFloat(e.target.value)}})}
                                        className="w-full bg-slate-800 border border-slate-600 rounded-xl pl-10 pr-4 py-2 text-white font-bold focus:border-green-500 outline-none"
                                    />
                                </div>
                            </div>
                            <div>
                                <label className="block text-slate-400 text-sm font-bold mb-1">Preço por Km (Opcional)</label>
                                <div className="relative">
                                    <span className="absolute left-3 top-3 text-slate-500">R$</span>
                                    <input 
                                        type="number" 
                                        step="0.10"
                                        value={pricing.moto.pricePerKm}
                                        onChange={(e) => setPricing({...pricing, moto: {...pricing.moto, pricePerKm: parseFloat(e.target.value)}})}
                                        className="w-full bg-slate-800 border border-slate-600 rounded-xl pl-10 pr-4 py-2 text-white font-bold focus:border-green-500 outline-none"
                                    />
                                </div>
                                <p className="text-[10px] text-slate-500 mt-1">Se 0, cobra apenas a taxa fixa.</p>
                            </div>
                        </div>
                    </div>

                    {/* Car Config */}
                    <div className="bg-slate-900 p-6 rounded-2xl border border-slate-700 relative overflow-hidden">
                        <div className="absolute top-0 right-0 p-4 opacity-10 text-6xl">🚗</div>
                        <h3 className="text-xl font-bold text-blue-400 mb-4 flex items-center gap-2">
                             🚗 Carro
                        </h3>
                        <div className="space-y-4">
                            <div>
                                <label className="block text-slate-400 text-sm font-bold mb-1">Preço Base (Taxa Fixa)</label>
                                <div className="relative">
                                    <span className="absolute left-3 top-3 text-slate-500">R$</span>
                                    <input 
                                        type="number" 
                                        step="0.10"
                                        value={pricing.car.basePrice}
                                        onChange={(e) => setPricing({...pricing, car: {...pricing.car, basePrice: parseFloat(e.target.value)}})}
                                        className="w-full bg-slate-800 border border-slate-600 rounded-xl pl-10 pr-4 py-2 text-white font-bold focus:border-blue-500 outline-none"
                                    />
                                </div>
                            </div>
                            <div>
                                <label className="block text-slate-400 text-sm font-bold mb-1">Preço por Km (Opcional)</label>
                                <div className="relative">
                                    <span className="absolute left-3 top-3 text-slate-500">R$</span>
                                    <input 
                                        type="number" 
                                        step="0.10"
                                        value={pricing.car.pricePerKm}
                                        onChange={(e) => setPricing({...pricing, car: {...pricing.car, pricePerKm: parseFloat(e.target.value)}})}
                                        className="w-full bg-slate-800 border border-slate-600 rounded-xl pl-10 pr-4 py-2 text-white font-bold focus:border-blue-500 outline-none"
                                    />
                                </div>
                                <p className="text-[10px] text-slate-500 mt-1">Se 0, cobra apenas a taxa fixa.</p>
                            </div>
                        </div>
                    </div>

                    {/* Platform Fee Config */}
                    <div className="bg-slate-900 p-6 rounded-2xl border border-purple-500/30 relative overflow-hidden shadow-[0_0_20px_rgba(168,85,247,0.1)]">
                        <div className="absolute top-0 right-0 p-4 opacity-10 text-6xl">📊</div>
                        <h3 className="text-xl font-bold text-purple-400 mb-4 flex items-center gap-2">
                             💼 Taxas & Comissões
                        </h3>
                        <div className="space-y-4">
                            <div>
                                <label className="block text-slate-400 text-sm font-bold mb-1">Taxa da Plataforma (%)</label>
                                <p className="text-[10px] text-slate-500 mb-2">Porcentagem descontada do motorista por corrida.</p>
                                <div className="relative">
                                    <span className="absolute right-4 top-3 text-slate-500 font-bold">%</span>
                                    <input 
                                        type="number" 
                                        step="1"
                                        min="0"
                                        max="100"
                                        value={pricing.platformFee || 0}
                                        onChange={(e) => setPricing({...pricing, platformFee: parseFloat(e.target.value)})}
                                        className="w-full bg-slate-800 border border-purple-500/50 rounded-xl pl-4 pr-10 py-3 text-white text-2xl font-black focus:border-purple-400 outline-none"
                                    />
                                </div>
                                <div className="mt-4 p-3 bg-purple-500/10 rounded-lg border border-purple-500/20">
                                    <p className="text-xs text-purple-300">
                                        Ex: Em uma corrida de <strong>R$ 10,00</strong>, o app fica com <strong>R$ {(10 * ((pricing.platformFee || 0) / 100)).toFixed(2)}</strong> e o motorista com <strong>R$ {(10 * (1 - ((pricing.platformFee || 0) / 100))).toFixed(2)}</strong>.
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div className="mt-8 flex justify-end">
                    <button 
                        onClick={handleSavePricing}
                        disabled={savingConfig}
                        className="bg-green-500 hover:bg-green-600 text-slate-900 font-bold py-3 px-8 rounded-xl shadow-lg transition-transform active:scale-95 flex items-center gap-2"
                    >
                        {savingConfig ? 'Salvando...' : 'Salvar Novos Preços'}
                    </button>
                </div>
            </div>
        )}


        {/* --- USERS TAB (IMPROVED) --- */}
        {activeTab === 'users' && (
            <div className="bg-slate-800 rounded-2xl border border-slate-700 overflow-hidden flex flex-col min-h-[70vh] shadow-2xl">
                {/* Filters */}
                <div className="p-4 border-b border-slate-700 flex flex-col md:flex-row gap-4 justify-between items-center bg-slate-800/50">
                    <div className="flex gap-2 bg-slate-900 p-1 rounded-lg">
                        <button onClick={() => setUserFilter('ALL')} className={`px-4 py-1.5 rounded-md text-xs font-bold transition-colors ${userFilter === 'ALL' ? 'bg-slate-700 text-white' : 'text-slate-400 hover:text-white'}`}>Todos</button>
                        <button onClick={() => setUserFilter('DRIVER')} className={`px-4 py-1.5 rounded-md text-xs font-bold transition-colors ${userFilter === 'DRIVER' ? 'bg-green-600 text-white' : 'text-slate-400 hover:text-white'}`}>Motoristas</button>
                        <button onClick={() => setUserFilter('PASSENGER')} className={`px-4 py-1.5 rounded-md text-xs font-bold transition-colors ${userFilter === 'PASSENGER' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white'}`}>Passageiros</button>
                        <button onClick={() => setUserFilter('PENDING')} className={`px-4 py-1.5 rounded-md text-xs font-bold transition-colors flex items-center gap-1 ${userFilter === 'PENDING' ? 'bg-yellow-500 text-black' : 'text-yellow-500 hover:text-yellow-400'}`}>
                            <span>⚠️</span> Pendentes
                        </button>
                    </div>
                    <div className="relative w-full md:w-auto">
                        <span className="absolute left-3 top-2.5 text-slate-500">🔍</span>
                        <input 
                            type="text" 
                            placeholder="Buscar nome, CPF, placa..." 
                            value={searchTerm} 
                            onChange={(e) => setSearchTerm(e.target.value)} 
                            className="bg-slate-900 border border-slate-600 rounded-xl pl-10 pr-4 py-2 text-white w-full md:w-80 focus:ring-2 focus:ring-blue-500 outline-none placeholder:text-slate-600" 
                        />
                    </div>
                </div>
                
                <div className="flex-1 overflow-auto custom-scrollbar">
                    {loadingUsers ? (
                        <div className="flex justify-center items-center h-64"><div className="w-8 h-8 border-2 border-blue-500 border-t-transparent rounded-full animate-spin"></div></div>
                    ) : (
                        <table className="w-full text-sm text-left text-slate-400">
                            <thead className="text-xs text-slate-300 uppercase bg-slate-700/50 sticky top-0 z-10 backdrop-blur-md">
                                <tr>
                                    <th className="px-6 py-4">Usuário</th>
                                    <th className="px-6 py-4">Documentos / Veículo</th>
                                    <th className="px-6 py-4">Status</th>
                                    <th className="px-6 py-4">Carteira</th>
                                    <th className="px-6 py-4 text-right">Ações</th>
                                </tr>
                            </thead>
                            <tbody>
                                {filteredUsers.map(u => (
                                    <tr key={u.id} className="border-b border-slate-700/50 hover:bg-slate-700/30 transition-colors">
                                        <td className="px-6 py-4">
                                            <div className="flex items-center gap-3">
                                                <div className="w-12 h-12 rounded-full bg-slate-600 overflow-hidden border-2 border-slate-500 shrink-0 cursor-pointer hover:border-white transition-colors" onClick={() => setSelectedUser(u)}>
                                                    {u.photoUrl ? (
                                                        <img src={u.photoUrl} alt="Foto" className="w-full h-full object-cover" />
                                                    ) : (
                                                        <div className="w-full h-full flex items-center justify-center font-bold text-white text-lg">{u.name.charAt(0)}</div>
                                                    )}
                                                </div>
                                                <div>
                                                    <div className="font-bold text-white text-base">{u.name}</div>
                                                    <div className="text-xs text-slate-500">{u.email}</div>
                                                    <div className="text-[10px] text-slate-600 font-mono mt-0.5">{u.phone || 'Sem telefone'}</div>
                                                </div>
                                            </div>
                                        </td>
                                        <td className="px-6 py-4">
                                            {u.role === UserRole.DRIVER ? (
                                                <div className="space-y-1">
                                                    {u.cpf && <div className="text-xs bg-slate-700/50 px-2 py-0.5 rounded inline-block border border-slate-600">CPF: <span className="text-white font-mono">{u.cpf}</span></div>}
                                                    {u.vehiclePlate && (
                                                        <div className="flex items-center gap-2 text-xs">
                                                            <span className="text-yellow-500 font-bold">{u.vehicleType === 'MOTO' ? '🛵' : '🚗'} {u.vehiclePlate}</span>
                                                            <span className="text-slate-500">({u.vehicleColor})</span>
                                                        </div>
                                                    )}
                                                </div>
                                            ) : (
                                                <span className="text-slate-600 text-xs italic">N/A (Passageiro)</span>
                                            )}
                                        </td>
                                        <td className="px-6 py-4">
                                            {u.status === UserStatus.PENDING ? (
                                                <span className="px-2 py-1 rounded-lg text-xs font-bold bg-yellow-500/20 text-yellow-500 border border-yellow-500/30 animate-pulse">
                                                    ⚠️ PENDENTE
                                                </span>
                                            ) : u.status === UserStatus.BANNED ? (
                                                <span className="px-2 py-1 rounded-lg text-xs font-bold bg-red-500/20 text-red-500 border border-red-500/30">
                                                    🚫 BANIDO
                                                </span>
                                            ) : (
                                                <span className={`px-2 py-1 rounded-lg text-xs font-bold border ${u.role === UserRole.DRIVER ? 'bg-green-500/10 text-green-400 border-green-500/30' : 'bg-blue-500/10 text-blue-400 border-blue-500/30'}`}>
                                                    ✅ ATIVO
                                                </span>
                                            )}
                                        </td>
                                        <td className="px-6 py-4">
                                            <span className={`font-mono font-bold text-lg ${u.balance && u.balance > 0 ? 'text-green-400' : 'text-slate-500'}`}>R$ {(u.balance || 0).toFixed(2)}</span>
                                        </td>
                                        <td className="px-6 py-4 text-right space-x-2">
                                            {u.status === UserStatus.PENDING ? (
                                                <>
                                                 <button onClick={() => handleApprove(u)} className="bg-green-600 hover:bg-green-500 text-white px-3 py-2 rounded-lg text-xs font-bold shadow-lg">
                                                     ✅ Aprovar
                                                 </button>
                                                 <button onClick={() => handleReject(u)} className="bg-red-600 hover:bg-red-500 text-white px-3 py-2 rounded-lg text-xs font-bold shadow-lg">
                                                     ❌ Rejeitar
                                                 </button>
                                                </>
                                            ) : (
                                                <>
                                                <button onClick={() => setBalanceModalUser(u)} className="bg-slate-700 hover:bg-slate-600 text-white px-3 py-2 rounded-lg text-xs font-bold">
                                                    💰 Saldo
                                                </button>
                                                <button onClick={() => setSelectedUser(u)} className="bg-slate-700 hover:bg-slate-600 text-white px-3 py-2 rounded-lg text-xs font-bold border border-slate-600">
                                                    👁️ Detalhes
                                                </button>
                                                </>
                                            )}
                                        </td>
                                    </tr>
                                ))}
                                {filteredUsers.length === 0 && (
                                    <tr>
                                        <td colSpan={5} className="text-center py-10 text-slate-500">
                                            Nenhum usuário encontrado com os filtros atuais.
                                        </td>
                                    </tr>
                                )}
                            </tbody>
                        </table>
                    )}
                </div>
            </div>
        )}

        {/* --- OVERVIEW TAB --- */}
        {activeTab === 'overview' && (
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8 animate-fade-in">
                <div className="bg-slate-800 p-6 rounded-2xl border border-slate-700 shadow-lg">
                    <h3 className="text-slate-400 text-sm font-medium uppercase">Total Corridas</h3>
                    <p className="text-4xl font-black text-white mt-2">{totalRides}</p>
                </div>
                <div className="bg-slate-800 p-6 rounded-2xl border border-slate-700 shadow-lg">
                    <h3 className="text-slate-400 text-sm font-medium uppercase">Movimentado</h3>
                    <p className="text-4xl font-black text-green-400 mt-2">R$ {totalRevenue.toFixed(2)}</p>
                </div>
                <div className="bg-slate-800 p-6 rounded-2xl border border-slate-700 shadow-lg">
                    <h3 className="text-slate-400 text-sm font-medium uppercase">Lucro Admin ({pricing?.platformFee || 15}%)</h3>
                    <p className="text-4xl font-black text-yellow-400 mt-2">R$ {(totalRevenue * ((pricing?.platformFee || 15)/100)).toFixed(2)}</p>
                </div>
                <div className="bg-slate-800 p-6 rounded-2xl border border-slate-700 shadow-lg">
                    <h3 className="text-slate-400 text-sm font-medium uppercase">Usuários</h3>
                    <p className="text-4xl font-black text-blue-400 mt-2">{users.length}</p>
                </div>
            </div>
        )}

        {/* --- FINANCE TAB --- */}
        {activeTab === 'finance' && (
            <div className="bg-slate-800 rounded-2xl border border-slate-700 p-8 shadow-2xl animate-fade-in">
                <h2 className="text-2xl font-bold text-white mb-6 flex items-center gap-3"><span className="text-yellow-400">⚡</span> Configurar QR Codes de Recarga</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {rechargeOptions.map(opt => (
                        <div key={opt.id} className="bg-slate-900 border border-slate-700 rounded-2xl p-6 flex flex-col items-center hover:border-slate-500 transition-colors">
                            <span className="text-green-400 font-black text-3xl mb-4">R$ {opt.value},00</span>
                            <div className="w-48 h-48 bg-white rounded-xl flex items-center justify-center mb-6 overflow-hidden relative group shadow-inner">
                                {opt.qrCodeUrl ? <img src={opt.qrCodeUrl} alt="QR" className="w-full h-full object-contain" /> : <span className="text-slate-400 text-xs">Sem QR Code</span>}
                                <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                                    <span className="text-white text-xs font-bold">Alterar Imagem</span>
                                </div>
                            </div>
                            <label className="cursor-pointer w-full bg-blue-600 hover:bg-blue-500 text-white text-sm font-bold py-3 rounded-xl transition-colors text-center shadow-lg">
                                Upload Imagem QR <input type="file" className="hidden" accept="image/*" onChange={(e) => handleUploadQR(opt.id, e)} />
                            </label>
                        </div>
                    ))}
                </div>
            </div>
        )}

        {/* --- MODALS --- */}
        
        {/* ADD BALANCE MODAL */}
        {balanceModalUser && (
            <div className="fixed inset-0 z-[80] flex items-center justify-center p-4 animate-fade-in">
                <div className="absolute inset-0 bg-slate-900/90 backdrop-blur-sm" onClick={() => setBalanceModalUser(null)}></div>
                <div className="bg-slate-800 w-full max-w-sm rounded-2xl shadow-2xl border border-slate-600 p-8 relative z-10">
                    <h3 className="text-xl font-bold text-white mb-2">Adicionar Saldo</h3>
                    <p className="text-slate-400 text-sm mb-6">Beneficiário: <span className="text-green-400 font-bold text-lg block">{balanceModalUser.name}</span></p>
                    
                    <div className="relative mb-6">
                        <span className="absolute left-4 top-3 text-slate-500 font-bold">R$</span>
                        <input 
                            type="number" 
                            value={amountToAdd} 
                            onChange={(e) => setAmountToAdd(e.target.value)} 
                            className="w-full bg-slate-900 border-2 border-slate-600 rounded-xl pl-10 pr-4 py-3 text-white text-2xl font-bold focus:border-green-500 outline-none" 
                            placeholder="0.00" 
                            autoFocus
                        />
                    </div>
                    
                    <div className="flex gap-3">
                        <button onClick={() => setBalanceModalUser(null)} className="flex-1 py-3 bg-slate-700 hover:bg-slate-600 text-white rounded-xl font-bold transition-colors">Cancelar</button>
                        <button onClick={handleAddBalance} className="flex-1 py-3 bg-green-500 hover:bg-green-400 text-slate-900 rounded-xl font-bold shadow-lg shadow-green-500/20 transition-colors">Confirmar</button>
                    </div>
                </div>
            </div>
        )}

        {/* USER DETAILS MODAL */}
        {selectedUser && (
            <div className="fixed inset-0 z-[80] flex items-center justify-center p-4 animate-fade-in">
                <div className="absolute inset-0 bg-slate-900/90 backdrop-blur-sm" onClick={() => setSelectedUser(null)}></div>
                <div className="bg-slate-800 w-full max-w-md rounded-2xl shadow-2xl border border-slate-600 overflow-hidden relative z-10 flex flex-col max-h-[90vh]">
                     <div className="bg-slate-700/50 p-4 flex justify-between items-center border-b border-slate-600">
                         <h3 className="font-bold text-white text-lg">Detalhes do Usuário</h3>
                         <button onClick={() => setSelectedUser(null)} className="text-slate-400 hover:text-white bg-slate-700 rounded-full w-8 h-8 flex items-center justify-center">✕</button>
                     </div>
                     
                     <div className="p-6 overflow-y-auto custom-scrollbar">
                         {/* Photo */}
                         <div className="flex flex-col items-center mb-6">
                             <div className="w-32 h-32 rounded-full bg-slate-700 mb-4 overflow-hidden border-4 border-slate-500 shadow-xl">
                                 {selectedUser.photoUrl ? (
                                    <img src={selectedUser.photoUrl} alt="Profile" className="w-full h-full object-cover" />
                                 ) : (
                                    <div className="w-full h-full flex items-center justify-center text-5xl font-bold text-slate-400">{selectedUser.name.charAt(0)}</div>
                                 )}
                             </div>
                             <h2 className="text-2xl font-bold text-white text-center leading-tight">{selectedUser.name}</h2>
                             
                             {/* Status Badge */}
                             <div className="mt-2">
                                 {selectedUser.status === UserStatus.PENDING && <span className="bg-yellow-500 text-black font-bold px-3 py-1 rounded-full text-xs">PENDENTE</span>}
                                 {selectedUser.status === UserStatus.BANNED && <span className="bg-red-500 text-white font-bold px-3 py-1 rounded-full text-xs">BANIDO</span>}
                                 {selectedUser.status === UserStatus.ACTIVE && <span className="bg-green-500 text-white font-bold px-3 py-1 rounded-full text-xs">ATIVO</span>}
                             </div>

                             <span className={`mt-2 px-3 py-1 rounded-full text-xs font-bold border ${selectedUser.role === UserRole.DRIVER ? 'bg-green-500/20 text-green-400 border-green-500/50' : 'bg-blue-500/20 text-blue-400 border-blue-500/50'}`}>
                                 {selectedUser.role}
                             </span>
                         </div>
                         
                         {/* Info Grid */}
                         <div className="space-y-4 bg-slate-900/50 p-4 rounded-xl border border-slate-700">
                             <div className="grid grid-cols-2 gap-4">
                                 <div>
                                     <span className="text-[10px] text-slate-500 font-bold uppercase block mb-1">ID do Sistema</span>
                                     <span className="text-xs text-white font-mono bg-slate-800 px-2 py-1 rounded block truncate">{selectedUser.id}</span>
                                 </div>
                                 <div>
                                     <span className="text-[10px] text-slate-500 font-bold uppercase block mb-1">Saldo Atual</span>
                                     <span className="text-sm text-green-400 font-black block">R$ {(selectedUser.balance || 0).toFixed(2)}</span>
                                 </div>
                             </div>

                             <div className="border-t border-slate-700 my-2"></div>
                             
                             <div>
                                 <span className="text-[10px] text-slate-500 font-bold uppercase block mb-1">Email</span>
                                 <span className="text-sm text-white block">{selectedUser.email}</span>
                             </div>
                             <div>
                                 <span className="text-[10px] text-slate-500 font-bold uppercase block mb-1">Telefone</span>
                                 <span className="text-sm text-white block">{selectedUser.phone || 'Não informado'}</span>
                             </div>

                             {selectedUser.role === UserRole.DRIVER && (
                                 <>
                                 <div className="border-t border-slate-700 my-2 pt-2">
                                     <span className="text-xs text-green-500 font-bold uppercase mb-3 block">Dados do Motorista</span>
                                     
                                     <div className="grid grid-cols-1 gap-3">
                                         <div className="bg-slate-800 p-3 rounded-lg border border-slate-600">
                                            <span className="text-[10px] text-slate-500 font-bold uppercase block mb-1">CPF</span>
                                            <span className="text-lg text-white font-mono tracking-wider block">{selectedUser.cpf || 'PENDENTE'}</span>
                                         </div>
                                         
                                         <div className="bg-slate-800 p-3 rounded-lg border border-slate-600 flex justify-between items-center">
                                            <div>
                                                <span className="text-[10px] text-slate-500 font-bold uppercase block mb-1">Veículo</span>
                                                <span className="text-sm text-white font-bold block">{selectedUser.vehicleType === 'MOTO' ? 'Moto' : 'Carro'} - {selectedUser.vehicleColor}</span>
                                            </div>
                                            <div className="text-right">
                                                <span className="text-[10px] text-slate-500 font-bold uppercase block mb-1">Placa</span>
                                                <div className="bg-white text-black font-black px-2 py-0.5 rounded border-2 border-slate-300 text-sm font-mono shadow-sm">
                                                    {selectedUser.vehiclePlate}
                                                </div>
                                            </div>
                                         </div>
                                     </div>
                                 </div>
                                 </>
                             )}
                         </div>
                     </div>
                     
                     <div className="p-4 bg-slate-700/30 border-t border-slate-600 space-y-2">
                         <div className="flex gap-2">
                             <button 
                                onClick={() => { setSelectedUser(null); setBalanceModalUser(selectedUser); }}
                                className="flex-1 bg-green-600 hover:bg-green-500 text-white font-bold py-3 rounded-xl shadow-lg transition-transform active:scale-95"
                            >
                                 + Saldo
                             </button>
                             {selectedUser.role === UserRole.DRIVER && selectedUser.status === UserStatus.PENDING && (
                                <button onClick={() => { handleApprove(selectedUser); setSelectedUser(null); }} className="flex-1 bg-blue-600 text-white font-bold py-3 rounded-xl">
                                    Aprovar
                                </button>
                             )}
                         </div>
                         <button onClick={() => handleBan(selectedUser)} className="w-full text-red-500 hover:text-red-400 font-bold py-2 text-xs uppercase">
                             Banir Usuário
                         </button>
                     </div>
                </div>
            </div>
        )}

      </div>
    </div>
  );
};

export default AdminDashboard;
