
import React, { useState, useEffect, useRef } from 'react';
import Navbar from '../components/Navbar';
import RideRequest from '../components/RideRequest';
import MapPlaceholder from '../components/MapPlaceholder';
import ChatWindow from '../components/ChatWindow';
import SettingsModal from '../components/SettingsModal'; 
import RechargeModal from '../components/RechargeModal';
import { useAuth } from '../contexts/AuthContext';
import { useRide } from '../contexts/RideContext';
import { useToast } from '../contexts/ToastContext';
import { useTheme } from '../contexts/ThemeContext';
import { UserRole, RideStatus, Ride } from '../types';
import { NEIGHBORHOOD_CENTER } from '../constants';
import { generateRouteTip } from '../services/geminiService';

const Home = () => {
  const { user, logout } = useAuth();
  const { allRides, acceptRide, updateRideStatus, userLocation, updateUserLocation, currentRide, cancelRide } = useRide();
  const { addToast } = useToast();
  const { theme, toggleTheme } = useTheme();

  // --- ESTADOS DO MOTORISTA ---
  const [isDriverOnline, setIsDriverOnline] = useState(false);
  const [aiTip, setAiTip] = useState<string>('');
  const [showCelebration, setShowCelebration] = useState(false);
  const [newRideIds, setNewRideIds] = useState<Set<string>>(new Set());
  const [acceptedRideIds, setAcceptedRideIds] = useState<Set<string>>(new Set());
  
  // --- ESTADO DOS MODAIS ---
  const [showSettings, setShowSettings] = useState(false);
  const [showRecharge, setShowRecharge] = useState(false);
  const [viewingRide, setViewingRide] = useState<Ride | null>(null);
  const [settingsTab, setSettingsTab] = useState<'profile' | 'settings' | 'history'>('profile');
  
  // --- SAFETY TOOLKIT ---
  const [showSafetyMenu, setShowSafetyMenu] = useState(false);

  // --- FILTROS DE CORRIDA ---
  const [sortBy, setSortBy] = useState<'newest' | 'price' | 'proximity'>('newest');

  // Derived States
  const isDriver = user?.role === UserRole.DRIVER;
  const pendingRides = allRides.filter(r => r.status === RideStatus.PENDING);
  const activeRide = currentRide && (currentRide.status === RideStatus.ACCEPTED || currentRide.status === RideStatus.IN_PROGRESS) ? currentRide : null;
  const hasActiveRide = isDriver ? !!activeRide : !!currentRide;

  // --- REAL-TIME LOCATION TRACKING ---
  useEffect(() => {
    let watchId: number | null = null;

    if (navigator.geolocation) {
        if (isDriver) {
            watchId = navigator.geolocation.watchPosition(
                (pos) => {
                    updateUserLocation(pos.coords.latitude, pos.coords.longitude);
                },
                (err) => console.warn("GPS Watch Error:", err),
                { 
                    enableHighAccuracy: true, 
                    maximumAge: 0, 
                    timeout: 5000 
                }
            );
        } else {
            navigator.geolocation.getCurrentPosition(
                (pos) => updateUserLocation(pos.coords.latitude, pos.coords.longitude),
                (err) => { if (!userLocation) updateUserLocation(NEIGHBORHOOD_CENTER.lat, NEIGHBORHOOD_CENTER.lng); }
            );
        }
    } else {
         if (!userLocation) updateUserLocation(NEIGHBORHOOD_CENTER.lat, NEIGHBORHOOD_CENTER.lng);
    }

    return () => {
        if (watchId !== null) navigator.geolocation.clearWatch(watchId);
    };
  }, [isDriver]); 

  // --- AUDIO NOTIFICATION (Som Suave) ---
  const prevPendingRidesRef = useRef<string[]>([]);
  useEffect(() => {
    if (!isDriver) return;

    const currentIds = pendingRides.map(r => r.id);
    const prevIds = prevPendingRidesRef.current;
    const addedIds = currentIds.filter(id => !prevIds.includes(id));

    if (addedIds.length > 0) {
        if (isDriverOnline && !activeRide) {
            try {
                const audio = new Audio('https://assets.mixkit.co/active_storage/sfx/2869/2869-preview.mp3');
                audio.volume = 0.5;
                audio.play().catch(e => console.log("Audio play prevented", e));
                
                const newRide = allRides.find(r => r.id === addedIds[0]);
                const rideInfo = newRide ? `${newRide.origin.split(',')[0]} - R$ ${newRide.price.toFixed(2)}` : 'Nova corrida!';

                addToast(`🔔 Nova solicitação: ${rideInfo}`, 'info');

                setNewRideIds(prev => new Set([...prev, ...addedIds]));
                setTimeout(() => {
                    setNewRideIds(prev => {
                        const next = new Set(prev);
                        addedIds.forEach(id => next.delete(id));
                        return next;
                    });
                }, 4000);
            } catch (err) {
                console.warn("Notification error", err);
            }
        }
    }
    prevPendingRidesRef.current = currentIds;
  }, [pendingRides, isDriverOnline, activeRide, isDriver, allRides, addToast]);

  // --- GEMINI COPILOT ---
  useEffect(() => {
    if (activeRide && activeRide.status === RideStatus.ACCEPTED && !aiTip) {
        setAiTip('IA analisando trajeto...');
        generateRouteTip(activeRide.origin, activeRide.destination).then(tip => setAiTip(tip));
    } else if (!activeRide) {
        setAiTip('');
    }
  }, [activeRide]);

  // --- HELPERS ---
  const formatCurrency = (val: number) => new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(val);
  
  // Calculate Daily Earnings (Only rides from today)
  const completedRides = allRides.filter(r => r.status === RideStatus.COMPLETED && r.driverId === user?.id);
  const todayStart = new Date();
  todayStart.setHours(0,0,0,0);
  
  const dailyEarnings = completedRides
    .filter(r => r.timestamp >= todayStart.getTime())
    .reduce((acc, r) => acc + r.price, 0);

  const getMapTarget = () => {
      if (isDriver && activeRide) {
          if (activeRide.status === RideStatus.ACCEPTED) return { lat: activeRide.originLat!, lng: activeRide.originLng! };
          if (activeRide.status === RideStatus.IN_PROGRESS) return { lat: activeRide.destLat!, lng: activeRide.destLng! };
      }
      if (!isDriver && currentRide && currentRide.status !== RideStatus.PENDING) {
           if (currentRide.status === RideStatus.ACCEPTED) return { lat: currentRide.originLat!, lng: currentRide.originLng! };
           return { lat: currentRide.destLat!, lng: currentRide.destLng! };
      }
      return null;
  };

  const openWaze = (lat?: number, lng?: number, address?: string) => {
    if(lat && lng) window.open(`https://waze.com/ul?ll=${lat},${lng}&navigate=yes`, '_blank');
    else if (address) window.open(`https://waze.com/ul?q=${encodeURIComponent(address)}&navigate=yes`, '_blank');
  };

  const handleCompleteRide = () => {
    setShowCelebration(true);
    const audio = new Audio('https://assets.mixkit.co/active_storage/sfx/2000/2000-preview.mp3'); 
    audio.volume = 0.5;
    audio.play().catch(() => {});
    setTimeout(() => {
        updateRideStatus(RideStatus.COMPLETED);
        setShowCelebration(false);
        addToast("Viagem finalizada com sucesso!", 'success');
    }, 3000);
  };

  const handleDriverCancel = () => {
    if (window.confirm("ATENÇÃO: Cancelar corrida prejudica sua taxa de aceitação. Continuar?")) {
        cancelRide();
        addToast("Corrida cancelada.", 'warning');
    }
  };

  const handleAcceptRide = (rideId: string) => {
      if (!user) return;
      
      if (!user.photoUrl && user.role === UserRole.DRIVER) {
           addToast("Adicione uma foto de perfil para aceitar corridas.", 'error');
           setTimeout(() => {
               if(window.confirm("É recomendável ter uma foto de perfil. Deseja adicionar agora?")) {
                   openDriverSettings('profile');
               }
           }, 500);
           return;
      }
      
      if ((user.balance || 0) < 2.00) {
          addToast("Saldo insuficiente para aceitar corridas.", 'error');
          setShowRecharge(true);
          return;
      }

      setAcceptedRideIds(prev => {
          const next = new Set(prev);
          next.add(rideId);
          return next;
      });
      
      setViewingRide(null);

      setTimeout(() => {
          acceptRide(rideId, user.id);
          addToast("Corrida Aceita!", 'success');
          setTimeout(() => {
             setAcceptedRideIds(prev => {
                 const next = new Set(prev);
                 next.delete(rideId);
                 return next;
             });
          }, 500);
      }, 1500);
  };

  const toggleOnline = () => {
      const newState = !isDriverOnline;
      setIsDriverOnline(newState);
      addToast(newState ? "Você está ONLINE" : "Você está OFFLINE", newState ? 'success' : 'info');
  };

  const openDriverSettings = (tab: 'profile' | 'settings' | 'history' = 'profile') => {
      setSettingsTab(tab);
      setShowSettings(true);
  };
  
  // --- SAFETY FEATURES ---
  const handleShareRide = () => {
      if(!activeRide) return;
      const text = `Estou em uma viagem no AleixoDrive. \nDe: ${activeRide.origin} \nPara: ${activeRide.destination} \nPlaca: ${user?.vehiclePlate || 'N/A'}`;
      const url = `https://wa.me/?text=${encodeURIComponent(text)}`;
      window.open(url, '_blank');
      setShowSafetyMenu(false);
      addToast("Link gerado para WhatsApp", 'success');
  };
  
  const handleEmergencyCall = () => {
      window.open('tel:190', '_self');
      setShowSafetyMenu(false);
  };

  // --- SORTING LOGIC ---
  const getDistanceFromDriver = (ride: Ride) => {
    if (!userLocation || !ride.originLat || !ride.originLng) return Infinity;
    const dLat = ride.originLat - userLocation.lat;
    const dLng = ride.originLng - userLocation.lng;
    return (dLat * dLat) + (dLng * dLng);
  };

  const sortedPendingRides = [...pendingRides].sort((a, b) => {
    if (sortBy === 'price') return b.price - a.price; 
    if (sortBy === 'proximity') return getDistanceFromDriver(a) - getDistanceFromDriver(b); 
    return b.timestamp - a.timestamp; 
  });

  // --- UI RENDERERS ---

  const DriverHUD = () => (
    <div className="absolute top-0 left-0 right-0 z-30 p-3 pointer-events-none flex flex-col gap-2">
        {/* Top Row: Menu, Theme, Status */}
        <div className="flex justify-between items-center pointer-events-auto">
            <div className="flex items-center gap-2">
                 <button 
                    onClick={() => openDriverSettings('profile')}
                    className="bg-white dark:bg-slate-800 w-10 h-10 rounded-full border border-gray-200 dark:border-slate-700 shadow-md flex items-center justify-center overflow-hidden active:scale-95"
                >
                    {user?.photoUrl ? (
                        <img src={user.photoUrl} alt="Perfil" className="w-full h-full object-cover" />
                    ) : (
                        <span className="text-xl">☰</span>
                    )}
                </button>
                <button 
                    onClick={toggleTheme}
                    className="bg-white dark:bg-slate-800 w-10 h-10 rounded-full border border-gray-200 dark:border-slate-700 shadow-md flex items-center justify-center active:scale-95 text-lg"
                >
                    {theme === 'dark' ? '☀️' : '🌙'}
                </button>
            </div>
            
            <button 
                onClick={toggleOnline}
                className={`px-4 py-2 rounded-full text-xs font-black tracking-wider border shadow-lg transition-all active:scale-95 ${isDriverOnline ? 'bg-green-500 text-slate-900 border-green-400' : 'bg-red-500 text-white border-red-400'}`}
             >
                {isDriverOnline ? 'ONLINE' : 'OFFLINE'}
             </button>
        </div>

        {/* Second Row: Finance Cards (Saldo & Ganhos) */}
        <div className="flex gap-2 pointer-events-auto overflow-x-auto no-scrollbar">
            {/* CARD DE SALDO (ROXO) */}
            <button 
                onClick={() => setShowRecharge(true)}
                className="flex-1 bg-white/95 dark:bg-slate-800/95 backdrop-blur-md rounded-xl p-2.5 border-l-4 border-l-purple-500 border border-gray-200 dark:border-slate-700 shadow-lg flex items-center gap-3 active:bg-gray-50 dark:active:bg-slate-700 transition-colors"
            >
                 <div className="w-8 h-8 rounded-lg bg-purple-100 dark:bg-purple-500/20 flex items-center justify-center text-lg">
                    ⚡
                 </div>
                 <div className="text-left">
                     <p className="text-[10px] text-purple-600 dark:text-purple-400 font-bold uppercase">Saldo Conta</p>
                     <p className="text-sm font-black text-slate-800 dark:text-white">{formatCurrency(user?.balance || 0)}</p>
                 </div>
            </button>

            {/* CARD DE GANHOS (VERDE) */}
            <div className="flex-1 bg-white/95 dark:bg-slate-800/95 backdrop-blur-md rounded-xl p-2.5 border-l-4 border-l-green-500 border border-gray-200 dark:border-slate-700 shadow-lg flex items-center gap-3">
                 <div className="w-8 h-8 rounded-lg bg-green-100 dark:bg-green-500/20 flex items-center justify-center text-lg">
                    📈
                 </div>
                 <div>
                     <p className="text-[10px] text-green-600 dark:text-green-400 font-bold uppercase">Ganhos Hoje</p>
                     <p className="text-sm font-black text-slate-800 dark:text-white">{formatCurrency(dailyEarnings)}</p>
                 </div>
            </div>
        </div>
    </div>
  );

  return (
    <div key={user?.role} className="relative h-screen w-screen bg-gray-100 dark:bg-slate-900 overflow-hidden font-sans transition-colors duration-300">
      {/* --- CAMADA 0: MAPA (PERSISTENTE) --- */}
      <div className="absolute inset-0 z-0">
          <MapPlaceholder 
            location={userLocation} 
            destination={getMapTarget()}
            showRoute={hasActiveRide}
            className={`w-full h-full transition-all duration-700 ${isDriver && !isDriverOnline ? 'grayscale opacity-40' : 'grayscale-0 opacity-100'}`} 
         />
         
         {isDriver && isDriverOnline && !activeRide && (
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                 <div className="w-64 h-64 border border-green-500/30 rounded-full animate-ping opacity-20"></div>
            </div>
         )}
      </div>

      {/* --- CAMADA 1: INTERFACE DO PASSAGEIRO --- */}
      {!isDriver && (
         <>
            <Navbar />
            {/* ADJUSTED PADDING TOP TO PREVENT NAVBAR OVERLAP */}
            <div className="absolute inset-0 z-10 pointer-events-none flex flex-col items-center justify-start pt-20 sm:pt-24">
                <div className="w-full max-w-md pointer-events-auto px-2 sm:px-0 transition-all">
                    <RideRequest />
                </div>
            </div>
         </>
      )}

      {/* --- CAMADA 2: INTERFACE DO MOTORISTA --- */}
      {isDriver && (
        <>
            <DriverHUD />

            {/* STATE: OFFLINE */}
            {!isDriverOnline && (
                <div className="absolute bottom-0 left-0 right-0 z-20 flex flex-col items-center pb-12 animate-slide-up">
                     <div className="bg-white/95 dark:bg-slate-900/95 backdrop-blur-md p-8 rounded-t-3xl shadow-2xl w-full max-w-md flex flex-col items-center border-t border-gray-200 dark:border-slate-700 transition-colors duration-300">
                        <h2 className="text-slate-800 dark:text-white font-bold text-xl mb-4">Você está offline</h2>
                        
                        {/* Botão GO Gigante */}
                        <div className="relative mb-6">
                             <button 
                                onClick={toggleOnline}
                                className={`w-28 h-28 rounded-full flex items-center justify-center shadow-[0_0_40px_rgba(34,197,94,0.3)] border-4 border-white dark:border-slate-800 transition-transform active:scale-95 z-10 relative bg-green-500 hover:bg-green-400`}
                            >
                                <span className="text-slate-900 font-black text-3xl tracking-tighter">GO</span>
                            </button>
                        </div>

                        {/* Botão de Recarga */}
                        <button 
                             onClick={() => setShowRecharge(true)}
                             className="w-full bg-purple-600/10 hover:bg-purple-600/20 border border-purple-500/30 text-purple-600 dark:text-purple-400 font-bold py-3 rounded-xl flex items-center justify-center gap-2 mb-6 transition-colors"
                        >
                            <span className="text-lg">⚡</span> Recarregar Créditos
                        </button>
                        
                        <div className="grid grid-cols-2 gap-4 w-full">
                            <button onClick={() => openDriverSettings('history')} className="flex items-center justify-center gap-2 bg-gray-100 dark:bg-slate-800 p-3 rounded-xl text-slate-600 dark:text-slate-300 hover:text-green-500 transition-colors border border-gray-200 dark:border-slate-700">
                                <span className="text-lg">📜</span>
                                <span className="text-sm font-bold">Histórico</span>
                            </button>
                            <button onClick={() => openDriverSettings('settings')} className="flex items-center justify-center gap-2 bg-gray-100 dark:bg-slate-800 p-3 rounded-xl text-slate-600 dark:text-slate-300 hover:text-green-500 transition-colors border border-gray-200 dark:border-slate-700">
                                <span className="text-lg">⚙️</span>
                                <span className="text-sm font-bold">Config</span>
                            </button>
                        </div>
                        
                        {/* BOTÃO SAIR */}
                        <button 
                           onClick={logout} 
                           className="w-full mt-4 bg-red-50 hover:bg-red-100 dark:bg-red-900/10 dark:hover:bg-red-900/20 text-red-600 dark:text-red-400 font-bold py-3 rounded-xl transition-colors flex items-center justify-center gap-2 border border-transparent hover:border-red-200 dark:hover:border-red-900/30"
                        >
                            <span>🚪</span> Sair do App
                        </button>
                     </div>
                </div>
            )}

            {/* STATE: ONLINE & SEARCHING */}
            {isDriverOnline && !activeRide && (
                <div className="absolute bottom-0 left-0 right-0 z-20 flex flex-col max-h-[70vh] animate-slide-up">
                     <div className="flex justify-center mb-4 pointer-events-auto">
                          <button 
                            onClick={() => setIsDriverOnline(false)}
                            className="bg-red-500 text-white px-6 py-2 rounded-full font-bold shadow-lg border-2 border-white dark:border-slate-900 text-sm flex items-center gap-2 hover:bg-red-600 transition-colors"
                          >
                            <span className="w-2 h-2 bg-white rounded-full"></span>
                            PARAR
                          </button>
                     </div>

                     <div className="bg-white dark:bg-slate-900 rounded-t-3xl shadow-[0_-10px_40px_rgba(0,0,0,0.2)] dark:shadow-[0_-10px_40px_rgba(0,0,0,0.5)] border-t border-gray-200 dark:border-slate-800 flex flex-col overflow-hidden transition-colors duration-300">
                          <div className="p-4 border-b border-gray-200 dark:border-slate-800 bg-gray-50 dark:bg-slate-800/50 flex flex-col gap-3">
                              <h3 className="text-slate-500 dark:text-slate-400 font-bold text-xs uppercase text-center tracking-widest">
                                  {pendingRides.length} {pendingRides.length === 1 ? 'Solicitação' : 'Solicitações'} Próximas
                              </h3>
                              
                              {/* FILTERS */}
                              {pendingRides.length > 1 && (
                                  <div className="flex justify-center gap-2 overflow-x-auto pb-1 no-scrollbar">
                                      <button 
                                        onClick={() => setSortBy('newest')}
                                        className={`px-3 py-1.5 rounded-full text-[10px] font-bold uppercase transition-all border ${sortBy === 'newest' ? 'bg-slate-800 dark:bg-white text-white dark:text-slate-900 border-transparent' : 'bg-transparent text-slate-500 border-slate-300 dark:border-slate-700'}`}
                                      >
                                          Recentes
                                      </button>
                                      <button 
                                        onClick={() => setSortBy('price')}
                                        className={`px-3 py-1.5 rounded-full text-[10px] font-bold uppercase transition-all border ${sortBy === 'price' ? 'bg-green-500 text-slate-900 border-transparent' : 'bg-transparent text-slate-500 border-slate-300 dark:border-slate-700'}`}
                                      >
                                          Maior Valor $$$
                                      </button>
                                      <button 
                                        onClick={() => setSortBy('proximity')}
                                        className={`px-3 py-1.5 rounded-full text-[10px] font-bold uppercase transition-all border ${sortBy === 'proximity' ? 'bg-blue-500 text-white border-transparent' : 'bg-transparent text-slate-500 border-slate-300 dark:border-slate-700'}`}
                                      >
                                          Mais Perto 📍
                                      </button>
                                  </div>
                              )}
                          </div>

                          <div className="overflow-y-auto p-4 space-y-3 bg-white dark:bg-slate-900 min-h-[200px]">
                               {sortedPendingRides.length === 0 ? (
                                   <div className="flex flex-col items-center justify-center py-10 opacity-50">
                                       <div className="w-12 h-12 border-4 border-slate-300 dark:border-slate-700 border-t-green-500 rounded-full animate-spin mb-4"></div>
                                       <p className="text-slate-500 dark:text-slate-400 text-sm">Procurando passageiros...</p>
                                   </div>
                               ) : (
                                   sortedPendingRides.map(ride => {
                                       const isNew = newRideIds.has(ride.id);
                                       const isAccepting = acceptedRideIds.has(ride.id);

                                       return (
                                           <div 
                                                key={ride.id} 
                                                onClick={() => setViewingRide(ride)}
                                                className={`bg-gray-50 dark:bg-slate-800 rounded-2xl p-4 border relative overflow-hidden transition-all cursor-pointer hover:bg-gray-100 dark:hover:bg-slate-700 active:scale-[0.98] ${isNew ? 'border-yellow-400 ring-2 ring-yellow-400/20' : 'border-gray-200 dark:border-slate-700'}`}
                                            >
                                               {isNew && <div className="absolute top-0 right-0 bg-yellow-400 text-black text-[9px] font-bold px-2 py-0.5 rounded-bl-lg">NOVO</div>}
                                               
                                               <div className="flex justify-between items-center mb-3">
                                                   <div className="flex items-center gap-3">
                                                       <div className="bg-white dark:bg-slate-700 p-2 rounded-lg text-2xl border border-gray-200 dark:border-slate-600 shadow-sm">
                                                           {ride.type === 'MOTO' ? '🛵' : '🚗'}
                                                       </div>
                                                       <div>
                                                           <p className="text-slate-500 dark:text-slate-400 text-[10px] font-bold uppercase">{ride.distanceFormatted}</p>
                                                           <p className="text-slate-800 dark:text-white font-medium text-sm w-32 truncate">{ride.origin}</p>
                                                       </div>
                                                   </div>
                                                   <div className="text-right">
                                                       <p className="text-green-600 dark:text-green-400 font-black text-2xl">{formatCurrency(ride.price)}</p>
                                                       <p className="text-slate-500 text-[10px] font-bold uppercase">{ride.paymentMethod === 'PIX' ? 'PIX' : 'Dinheiro'}</p>
                                                   </div>
                                               </div>

                                               <button 
                                                    onClick={(e) => { e.stopPropagation(); !isAccepting && handleAcceptRide(ride.id); }}
                                                    disabled={isAccepting}
                                                    className={`w-full font-black py-3 rounded-xl uppercase tracking-wide shadow-lg transition-all duration-300 ${
                                                        isAccepting
                                                        ? 'bg-green-600 text-white scale-105 cursor-default'
                                                        : 'bg-green-500 hover:bg-green-400 text-slate-900'
                                                    }`}
                                               >
                                                   {isAccepting ? 'Aceito! 🚀' : `Aceitar Agora`}
                                               </button>
                                           </div>
                                       );
                                   })
                               )}
                          </div>
                     </div>
                </div>
            )}

            {/* STATE: ACTIVE RIDE */}
            {activeRide && (
                <>
                    {/* SAFETY TOOLKIT BUTTON (Shield) */}
                    <div className="absolute top-4 right-4 z-40">
                         <button 
                            onClick={() => setShowSafetyMenu(!showSafetyMenu)}
                            className="bg-white dark:bg-slate-800 text-blue-500 w-12 h-12 rounded-full shadow-xl flex items-center justify-center border-2 border-blue-500 active:scale-95 transition-all"
                         >
                            🛡️
                         </button>
                         {showSafetyMenu && (
                             <div className="absolute top-14 right-0 bg-white dark:bg-slate-800 rounded-xl shadow-2xl border border-gray-200 dark:border-slate-700 w-48 overflow-hidden animate-fade-in">
                                 <button onClick={handleShareRide} className="w-full text-left px-4 py-3 hover:bg-gray-100 dark:hover:bg-slate-700 text-slate-700 dark:text-white text-sm font-bold flex items-center gap-2">
                                     <span>🔗</span> Compartilhar Rota
                                 </button>
                                 <div className="border-t border-gray-200 dark:border-slate-700"></div>
                                 <button onClick={handleEmergencyCall} className="w-full text-left px-4 py-3 hover:bg-red-50 dark:hover:bg-red-900/20 text-red-600 text-sm font-bold flex items-center gap-2">
                                     <span>🆘</span> Ligar 190
                                 </button>
                             </div>
                         )}
                    </div>

                    {/* Instruction Overlay */}
                    <div className="absolute top-28 left-4 right-4 z-20 animate-slide-down">
                        <div className="bg-white/90 dark:bg-slate-900/90 backdrop-blur-md rounded-xl p-4 shadow-2xl border border-gray-200 dark:border-slate-700 flex items-center justify-between">
                            <div>
                                <p className="text-xs text-slate-500 dark:text-slate-400 font-bold uppercase mb-1">
                                    {activeRide.status === RideStatus.ACCEPTED ? 'Pegar passageiro em:' : 'Levar passageiro para:'}
                                </p>
                                <h2 className="text-lg font-bold text-slate-800 dark:text-white leading-tight">
                                    {activeRide.status === RideStatus.ACCEPTED ? activeRide.origin : activeRide.destination}
                                </h2>
                                {aiTip && <p className="text-blue-500 dark:text-blue-400 text-xs mt-2 italic">💡 {aiTip}</p>}
                            </div>
                            <div className="bg-gray-100 dark:bg-slate-800 p-2 rounded-lg">
                                 <div className="text-xl">{activeRide.type === 'MOTO' ? '🛵' : '🚗'}</div>
                            </div>
                        </div>
                    </div>

                    {/* Action Sheet */}
                    <div className="absolute bottom-0 left-0 right-0 bg-white dark:bg-slate-900 z-30 rounded-t-3xl shadow-[0_-10px_40px_rgba(0,0,0,0.3)] dark:shadow-[0_-10px_40px_rgba(0,0,0,0.6)] p-6 pb-8 border-t border-gray-200 dark:border-slate-700 animate-slide-up transition-colors duration-300">
                          <button 
                             onClick={() => activeRide.status === RideStatus.ACCEPTED 
                                ? openWaze(activeRide.originLat, activeRide.originLng, activeRide.origin)
                                : openWaze(activeRide.destLat, activeRide.destLng, activeRide.destination)
                            }
                            className="w-full bg-blue-600 hover:bg-blue-500 text-white font-black py-4 rounded-xl shadow-lg mb-4 flex items-center justify-center gap-2 text-lg uppercase tracking-wide border-b-4 border-blue-800 active:border-b-0 active:translate-y-1"
                          >
                             <svg className="w-6 h-6" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 17.93c-3.95-.49-7-3.85-7-7.93 0-.62.08-1.21.21-1.79L9 15v1c0 1.1.9 2 2 2v1.93zm6.9-2.54c-.26-.81-1-1.39-1.9-1.39h-1v-3c0-.55-.45-1-1-1H8v-2h2c.55 0 1-.45 1-1V7h2c1.1 0 2-.9 2-2v-.41c2.93 1.19 5 4.06 5 7.41 0 2.08-.8 3.97-2.1 5.39z"/></svg>
                             Navegar (Waze)
                          </button>

                          <div className="flex items-center justify-between mb-6 px-1">
                               <div className="flex items-center gap-3">
                                   <div className="w-10 h-10 bg-gray-200 dark:bg-slate-700 rounded-full flex items-center justify-center text-xl">👤</div>
                                   <div className="flex flex-col">
                                       <span className="text-slate-800 dark:text-white font-bold text-sm">Passageiro</span>
                                       <span className="text-green-600 dark:text-green-400 text-xs font-bold bg-green-100 dark:bg-green-900/20 px-1.5 rounded">{activeRide.paymentMethod === 'PIX' ? 'PIX' : 'DINHEIRO'}</span>
                                   </div>
                               </div>
                               <div className="text-right">
                                   <p className="text-green-600 dark:text-green-400 font-black text-2xl">{formatCurrency(activeRide.price)}</p>
                               </div>
                          </div>

                          {activeRide.status === RideStatus.ACCEPTED ? (
                              <div className="space-y-3">
                                  <button onClick={() => updateRideStatus(RideStatus.IN_PROGRESS)} className="w-full bg-green-500 hover:bg-green-400 text-slate-900 font-black py-4 rounded-xl text-lg uppercase shadow-lg">
                                      Iniciar Viagem
                                  </button>
                                  <div className="flex justify-between items-center px-2">
                                      <button onClick={handleDriverCancel} className="text-red-500 text-xs font-bold hover:underline">Cancelar</button>
                                      <div className="w-1/2">
                                          <ChatWindow />
                                      </div>
                                  </div>
                              </div>
                          ) : (
                              <button onClick={handleCompleteRide} className="w-full bg-red-600 hover:bg-red-500 text-white font-black py-4 rounded-xl text-lg uppercase shadow-lg">
                                  Finalizar Viagem
                              </button>
                          )}
                    </div>
                </>
            )}

            {/* Celebration Overlay */}
            {showCelebration && (
                <div className="absolute inset-0 z-[100] bg-green-500 flex flex-col items-center justify-center animate-fade-in">
                    <h1 className="text-6xl mb-4">🎉</h1>
                    <h2 className="text-4xl font-black text-white">VIAGEM CONCLUÍDA!</h2>
                    <div className="bg-white text-green-600 font-black text-5xl px-10 py-6 rounded-3xl mt-8 shadow-2xl">
                        {formatCurrency(activeRide ? activeRide.price : 0)}
                    </div>
                    <p className="text-white/80 font-bold mt-8 text-lg animate-pulse">Bom trabalho!</p>
                </div>
            )}
            
            {/* Modal de Detalhes da Corrida */}
            {viewingRide && (
                <div className="fixed inset-0 z-50 flex items-center justify-center p-4 animate-fade-in">
                     <div className="absolute inset-0 bg-slate-900/80 backdrop-blur-sm" onClick={() => setViewingRide(null)}></div>
                     <div className="bg-white dark:bg-slate-800 w-full max-w-md rounded-2xl shadow-2xl border border-gray-200 dark:border-slate-700 relative z-10 overflow-hidden flex flex-col animate-slide-up">
                         {/* Header */}
                         <div className="bg-slate-50 dark:bg-slate-800/80 p-4 border-b border-gray-200 dark:border-slate-700 flex justify-between items-center">
                             <h3 className="text-slate-800 dark:text-white font-bold">Detalhes da Corrida</h3>
                             <button onClick={() => setViewingRide(null)} className="p-2 text-slate-400 hover:text-red-500">✕</button>
                         </div>

                         {/* Content */}
                         <div className="p-6 space-y-6">
                              <div className="text-center">
                                  <p className="text-sm text-slate-500 dark:text-slate-400 font-bold uppercase mb-1">Valor Total</p>
                                  <h2 className="text-5xl font-black text-green-500">{formatCurrency(viewingRide.price)}</h2>
                                  <span className="inline-block mt-2 px-3 py-1 bg-gray-100 dark:bg-slate-700 rounded-lg text-xs font-bold text-slate-600 dark:text-slate-300 uppercase">
                                      Pagamento: {viewingRide.paymentMethod === 'PIX' ? 'PIX' : 'Dinheiro'}
                                  </span>
                              </div>

                              <div className="space-y-4 bg-gray-50 dark:bg-slate-900 p-4 rounded-xl border border-gray-200 dark:border-slate-700">
                                   <div className="flex gap-3">
                                       <div className="flex flex-col items-center mt-1">
                                           <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                                           <div className="w-0.5 h-full bg-gray-300 dark:bg-slate-700 min-h-[20px]"></div>
                                       </div>
                                       <div>
                                           <p className="text-[10px] font-bold text-slate-500 uppercase">Origem</p>
                                           <p className="text-slate-800 dark:text-white text-sm font-medium">{viewingRide.origin}</p>
                                       </div>
                                   </div>
                                   <div className="flex gap-3">
                                       <div className="w-3 h-3 bg-red-500 rounded-full mt-1"></div>
                                       <div>
                                           <p className="text-[10px] font-bold text-slate-500 uppercase">Destino</p>
                                           <p className="text-slate-800 dark:text-white text-sm font-medium">{viewingRide.destination}</p>
                                       </div>
                                   </div>
                              </div>
                              
                              {viewingRide.notes && (
                                  <div className="bg-yellow-50 dark:bg-yellow-900/10 border border-yellow-200 dark:border-yellow-900/30 p-4 rounded-xl">
                                      <p className="text-[10px] font-bold text-yellow-600 dark:text-yellow-400 uppercase mb-1">Observações do Passageiro:</p>
                                      <p className="text-slate-800 dark:text-yellow-100 text-sm italic">"{viewingRide.notes}"</p>
                                  </div>
                              )}
                         </div>

                         <div className="p-4 border-t border-gray-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/50">
                             <button 
                                onClick={() => handleAcceptRide(viewingRide.id)}
                                className="w-full bg-green-500 hover:bg-green-600 text-slate-900 font-black py-4 rounded-xl text-lg uppercase shadow-lg transition-transform active:scale-95"
                             >
                                 ACEITAR CORRIDA
                             </button>
                         </div>
                     </div>
                </div>
            )}
            
            <SettingsModal 
                isOpen={showSettings}
                onClose={() => setShowSettings(false)}
                defaultTab={settingsTab}
            />
            
            <RechargeModal 
                isOpen={showRecharge}
                onClose={() => setShowRecharge(false)}
            />
        </>
      )}
    </div>
  );
};

export default Home;
