
import React, { useState, useRef } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { UserRole } from '../types';

const Login = () => {
  const { login, signup } = useAuth();
  const [isLogin, setIsLogin] = useState(true);
  const [loading, setLoading] = useState(false);

  // Form State
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [role, setRole] = useState<UserRole>(UserRole.PASSENGER);
  
  // Extra Fields
  const [phone, setPhone] = useState('');
  const [cpf, setCpf] = useState('');
  
  // Vehicle Data
  const [vehicleType, setVehicleType] = useState('CAR');
  const [plate, setPlate] = useState('');
  const [vehicleColor, setVehicleColor] = useState('');
  
  // Photo Logic
  const [photoBase64, setPhotoBase64] = useState<string>('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Masks
  const handleCpfChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      let v = e.target.value.replace(/\D/g, '');
      if (v.length > 11) v = v.slice(0, 11);
      v = v.replace(/(\d{3})(\d)/, '$1.$2');
      v = v.replace(/(\d{3})(\d)/, '$1.$2');
      v = v.replace(/(\d{3})(\d{1,2})$/, '$1-$2');
      setCpf(v);
  };

  const handlePhoneChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      let v = e.target.value.replace(/\D/g, '');
      if (v.length > 11) v = v.slice(0, 11);
      v = v.replace(/^(\d{2})(\d)/g, '($1) $2');
      v = v.replace(/(\d)(\d{4})$/, '$1-$2');
      setPhone(v);
  };

  // Camera/Image Logic
  const handleCapture = async (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if (!file) return;

      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = (event) => {
          const img = new Image();
          img.src = event.target?.result as string;
          img.onload = () => {
              const canvas = document.createElement('canvas');
              const ctx = canvas.getContext('2d');
              const MAX_WIDTH = 400;
              const scaleSize = MAX_WIDTH / img.width;
              canvas.width = MAX_WIDTH;
              canvas.height = img.height * scaleSize;
              ctx?.drawImage(img, 0, 0, canvas.width, canvas.height);
              setPhotoBase64(canvas.toDataURL('image/jpeg', 0.6));
          };
      };
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
        if (isLogin) {
            await login(email, password, role); 
        } else {
            // Validações Extras para Motorista
            if (role === UserRole.DRIVER) {
                if (!photoBase64) {
                    alert("Motorista, é obrigatório tirar uma selfie agora.");
                    setLoading(false);
                    return;
                }
                if (cpf.length < 14) {
                    alert("CPF inválido.");
                    setLoading(false);
                    return;
                }
            }

            const extraData = {
                phone,
                cpf: role === UserRole.DRIVER ? cpf : undefined,
                vehicleType: role === UserRole.DRIVER ? vehicleType : undefined,
                vehiclePlate: role === UserRole.DRIVER ? plate : undefined,
                vehicleColor: role === UserRole.DRIVER ? vehicleColor : undefined,
                photoUrl: role === UserRole.DRIVER ? photoBase64 : undefined
            };

            await signup(name, email, password, role, extraData);
        }
        window.location.hash = '';
    } catch (err) {
        alert("Erro na autenticação. Verifique os dados.");
    } finally {
        setLoading(false);
    }
  };

  const prepareAdminLogin = () => {
      setIsLogin(true);
      setEmail(''); 
      setPassword('');
  };

  return (
    <div className="min-h-screen flex items-center justify-center px-4 py-12 relative">
      <div className="w-full max-w-md bg-slate-800 rounded-2xl shadow-2xl border border-slate-700 overflow-hidden relative z-10">
        <div className="flex border-b border-slate-700">
            <button 
                onClick={() => setIsLogin(true)} 
                className={`flex-1 py-4 font-semibold text-sm ${isLogin ? 'bg-slate-700 text-white' : 'text-slate-400 hover:text-white'}`}
            >
                Login
            </button>
            <button 
                onClick={() => setIsLogin(false)} 
                className={`flex-1 py-4 font-semibold text-sm ${!isLogin ? 'bg-slate-700 text-white' : 'text-slate-400 hover:text-white'}`}
            >
                Cadastrar
            </button>
        </div>

        <div className="p-8 max-h-[80vh] overflow-y-auto custom-scrollbar">
            <div className="text-center mb-6">
                <h1 className="text-3xl font-bold text-white mb-2">Aleixo<span className="text-green-500">Drive</span></h1>
                <p className="text-slate-400 text-sm">Mobilidade rápida para o seu bairro.</p>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
                {!isLogin && (
                    <>
                        <div>
                            <label className="block text-xs font-medium text-slate-400 mb-1">Nome Completo</label>
                            <input type="text" required value={name} onChange={e => setName(e.target.value)} className="w-full bg-slate-900 border border-slate-600 rounded-lg p-3 text-white outline-none" />
                        </div>
                        <div>
                            <label className="block text-xs font-medium text-slate-400 mb-1">Celular / WhatsApp</label>
                            <input type="text" required value={phone} onChange={handlePhoneChange} placeholder="(92) 99999-9999" className="w-full bg-slate-900 border border-slate-600 rounded-lg p-3 text-white outline-none" />
                        </div>
                    </>
                )}

                <div>
                    <label className="block text-xs font-medium text-slate-400 mb-1">Email</label>
                    <input type="email" required value={email} onChange={e => setEmail(e.target.value)} className="w-full bg-slate-900 border border-slate-600 rounded-lg p-3 text-white outline-none" />
                </div>

                <div>
                    <label className="block text-xs font-medium text-slate-400 mb-1">Senha</label>
                    <input type="password" required value={password} onChange={e => setPassword(e.target.value)} className="w-full bg-slate-900 border border-slate-600 rounded-lg p-3 text-white outline-none" />
                </div>

                <div className="pt-2">
                     <label className="block text-xs font-medium text-slate-400 mb-2">Eu sou:</label>
                     <div className="flex gap-2">
                        <button type="button" onClick={() => setRole(UserRole.PASSENGER)} className={`flex-1 py-2 rounded-lg border ${role === UserRole.PASSENGER ? 'border-green-500 bg-green-500/20 text-white' : 'border-slate-600 text-slate-400'}`}>Passageiro</button>
                        <button type="button" onClick={() => setRole(UserRole.DRIVER)} className={`flex-1 py-2 rounded-lg border ${role === UserRole.DRIVER ? 'border-green-500 bg-green-500/20 text-white' : 'border-slate-600 text-slate-400'}`}>Motorista</button>
                     </div>
                </div>

                {!isLogin && role === UserRole.DRIVER && (
                    <div className="bg-slate-900 p-4 rounded-lg space-y-3 border border-slate-700 animate-fade-in border-l-4 border-l-green-500">
                        <p className="text-xs font-bold text-green-400 uppercase tracking-wider mb-2">Dados do Motorista (Obrigatório)</p>
                         
                         <div>
                            <label className="block text-xs text-slate-500 mb-1">CPF</label>
                            <input type="text" required value={cpf} onChange={handleCpfChange} placeholder="000.000.000-00" className="w-full bg-slate-800 border border-slate-600 text-white rounded p-2 text-sm outline-none" />
                         </div>

                         <div className="flex gap-2">
                            <div className="flex-1">
                                <label className="block text-xs text-slate-500 mb-1">Veículo</label>
                                <select value={vehicleType} onChange={e => setVehicleType(e.target.value)} className="w-full bg-slate-800 border border-slate-600 text-white rounded p-2 text-sm">
                                    <option value="MOTO">Moto</option>
                                    <option value="CAR">Carro</option>
                                </select>
                            </div>
                            <div className="flex-1">
                                <label className="block text-xs text-slate-500 mb-1">Placa</label>
                                <input type="text" placeholder="ABC-1234" required value={plate} onChange={e => setPlate(e.target.value.toUpperCase())} className="w-full bg-slate-800 border border-slate-600 text-white rounded p-2 text-sm outline-none" />
                            </div>
                         </div>
                         
                         <div>
                            <label className="block text-xs text-slate-500 mb-1">Cor do Veículo</label>
                            <input type="text" placeholder="Ex: Vermelho, Preto..." required value={vehicleColor} onChange={e => setVehicleColor(e.target.value)} className="w-full bg-slate-800 border border-slate-600 text-white rounded p-2 text-sm outline-none" />
                         </div>

                         {/* SELFIE SECTION */}
                         <div className="pt-2">
                             <label className="block text-xs font-bold text-slate-300 mb-2">Selfie Agora (Obrigatório)</label>
                             <div className="flex items-center gap-4">
                                 <div className="w-16 h-16 rounded-full bg-slate-700 overflow-hidden border-2 border-slate-500">
                                     {photoBase64 ? (
                                         <img src={photoBase64} alt="Selfie" className="w-full h-full object-cover" />
                                     ) : (
                                         <div className="w-full h-full flex items-center justify-center text-slate-500 text-xs">Sem Foto</div>
                                     )}
                                 </div>
                                 <button 
                                    type="button"
                                    onClick={() => fileInputRef.current?.click()}
                                    className="bg-green-600 hover:bg-green-500 text-white text-xs px-4 py-2 rounded-lg font-bold flex items-center gap-2"
                                 >
                                    <span>📸</span> Tirar Foto
                                 </button>
                                 <input 
                                    type="file" 
                                    accept="image/*" 
                                    capture="user" // Forces camera on mobile
                                    ref={fileInputRef} 
                                    onChange={handleCapture}
                                    className="hidden" 
                                 />
                             </div>
                             {!photoBase64 && <p className="text-[10px] text-red-400 mt-1">* Foto necessária para segurança</p>}
                         </div>
                    </div>
                )}

                <button disabled={loading} type="submit" className="w-full bg-green-500 hover:bg-green-600 text-slate-900 font-bold py-3 rounded-lg mt-4 transition-colors shadow-lg">
                    {loading ? 'Processando...' : (isLogin ? 'Entrar' : 'Cadastrar Grátis')}
                </button>
            </form>
        </div>
      </div>
      
      {/* Admin Link Footer */}
      <div className="absolute bottom-6 w-full text-center z-0">
         <button 
            onClick={prepareAdminLogin}
            className="text-[10px] text-slate-600 hover:text-green-500 uppercase font-bold tracking-widest transition-colors flex items-center justify-center gap-2 mx-auto opacity-70 hover:opacity-100"
         >
            <span className="text-lg">🛡️</span> Painel Administrativo
         </button>
      </div>
    </div>
  );
};

export default Login;
