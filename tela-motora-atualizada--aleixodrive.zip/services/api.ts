
import { User, UserRole, RechargeOption, PricingRules, UserStatus } from '../types';

const API_URL = (import.meta as any).env?.VITE_API_URL || 'http://localhost:4000/api';

const generateUUID = () => {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
    var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
    return v.toString(16);
  });
};

// --- SMART MOCK DATABASE (MEMÓRIA VIVA) ---
// Isso garante que se você cadastrar um usuário no modo offline, ele apareça no admin
let localMockUsers: User[] = [
    { 
        id: 'u1', 
        name: 'Carlos Silva (Demo)', 
        email: 'carlos@email.com', 
        role: UserRole.DRIVER, 
        status: UserStatus.ACTIVE,
        balance: 10.50, 
        vehiclePlate: 'NOX-1234', 
        vehicleType: 'MOTO',
        phone: '(92) 99123-4567',
        cpf: '000.111.222-33',
        vehicleColor: 'Vermelha'
    },
    { 
        id: 'u2', 
        name: 'Ana Souza (Demo)', 
        email: 'ana@email.com', 
        role: UserRole.PASSENGER, 
        status: UserStatus.ACTIVE,
        balance: 0,
        phone: '(92) 98888-7777' 
    },
    { 
        id: 'admin-01', 
        name: 'Administrador Supremo', 
        email: 'jottanobru@gmail.com', 
        role: UserRole.ADMIN, 
        status: UserStatus.ACTIVE,
        balance: 999999 
    }
];

let localMockPricing: PricingRules = {
    moto: { basePrice: 4.50, pricePerKm: 0 },
    car: { basePrice: 7.00, pricePerKm: 0 },
    platformFee: 15 // Padrão 15%
};

const mockServer = {
    login: async (email: string, pass: string, roleHint?: UserRole) => {
        // Verifica admin hardcoded
        if (email === "jottanobru@gmail.com" && pass === "40028922") {
            return { success: true, user: localMockUsers.find(u => u.role === UserRole.ADMIN) };
        }
        
        // Verifica users na memória local
        const found = localMockUsers.find(u => u.email === email);
        if (found) {
            // Mock status check
            if (found.status === UserStatus.BANNED) return { success: false, message: 'Banido' };
            if (found.role === UserRole.DRIVER && found.status === UserStatus.PENDING) return { success: false, message: 'Pendente' };
            return { success: true, user: found };
        }

        // Fallback genérico (apenas se não achar nada)
        return { 
            success: true, 
            user: { 
                id: generateUUID(), 
                name: 'Usuário (Modo Local)', 
                email, 
                role: roleHint || 'PASSENGER', 
                status: 'ACTIVE',
                vehicleType: roleHint === 'DRIVER' ? 'CAR' : undefined,
                vehiclePlate: roleHint === 'DRIVER' ? 'ABC-1234' : undefined,
                balance: 0
            } 
        };
    },
    signup: async (data: any) => {
        const newUser: User = { 
            id: generateUUID(), 
            ...data, 
            role: data.role,
            status: data.role === 'DRIVER' ? UserStatus.PENDING : UserStatus.ACTIVE,
            rating: 5.0,
            balance: 0
        };
        // SALVA NA MEMÓRIA LOCAL DO NAVEGADOR (SESSÃO ATUAL)
        localMockUsers.push(newUser);
        return { success: true, user: newUser };
    },
    getRechargeOptions: async () => {
        return {
            success: true,
            options: [
                { id: 'opt-2', value: 2, qrCodeUrl: '' },
                { id: 'opt-4', value: 4, qrCodeUrl: '' },
                { id: 'opt-6', value: 6, qrCodeUrl: '' },
                { id: 'opt-8', value: 8, qrCodeUrl: '' },
                { id: 'opt-10', value: 10, qrCodeUrl: '' }
            ]
        }
    },
    getUsers: async () => {
        // Retorna a lista atualizada (incluindo novos cadastros)
        return {
            success: true,
            users: [...localMockUsers]
        };
    },
    addBalance: async (userId: string, amount: number) => {
        const idx = localMockUsers.findIndex(u => u.id === userId);
        if (idx !== -1) {
            localMockUsers[idx].balance = (localMockUsers[idx].balance || 0) + amount;
            return { success: true, newBalance: localMockUsers[idx].balance };
        }
        return { success: true };
    },
    approveDriver: async (userId: string) => {
        const idx = localMockUsers.findIndex(u => u.id === userId);
        if (idx !== -1) localMockUsers[idx].status = UserStatus.ACTIVE;
        return { success: true };
    },
    rejectDriver: async (userId: string) => {
        const idx = localMockUsers.findIndex(u => u.id === userId);
        if (idx !== -1) localMockUsers[idx].status = UserStatus.REJECTED;
        return { success: true };
    },
    banUser: async (userId: string) => {
        const idx = localMockUsers.findIndex(u => u.id === userId);
        if (idx !== -1) localMockUsers[idx].status = UserStatus.BANNED;
        return { success: true };
    },
    getSystemErrors: async () => {
        return { success: true, errors: [] };
    },
    // PRICING
    getPricing: async () => {
        return { success: true, pricing: localMockPricing };
    },
    updatePricing: async (pricing: PricingRules) => {
        localMockPricing = pricing;
        return { success: true, pricing: localMockPricing };
    }
};

const fetchWithTimeout = async (url: string, options: RequestInit = {}, timeout = 3000) => {
    const controller = new AbortController();
    const id = setTimeout(() => controller.abort(), timeout);
    try {
        const response = await fetch(url, {
            ...options,
            signal: controller.signal
        });
        clearTimeout(id);
        return response;
    } catch (error) {
        clearTimeout(id);
        throw error;
    }
};

export const api = {
  async login(email: string, password: string, roleHint?: UserRole) {
    try {
        const res = await fetchWithTimeout(`${API_URL}/login`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email, password })
        });
        const data = await res.json();
        // Propagate error message
        if (!data.success && res.status === 403) throw new Error(data.message);
        if (!res.ok) throw new Error("Server error");
        return data;
    } catch (e: any) {
        // Se for erro de validação (403), repassa
        if (e.message && (e.message.includes('banida') || e.message.includes('análise') || e.message.includes('recusado'))) {
            throw e;
        }
        console.warn("Server unavailable (Timeout/Error), using Local Mock.");
        return await mockServer.login(email, password, roleHint);
    }
  },

  async signup(userData: any) {
      try {
        const res = await fetchWithTimeout(`${API_URL}/signup`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(userData)
        });
        if (!res.ok) throw new Error("Server error");
        return await res.json();
      } catch (e) {
          console.warn("Server unavailable, saving to Local Mock.");
          return await mockServer.signup(userData);
      }
  },

  async updateProfile(userId: string, data: any) {
      try {
        const res = await fetchWithTimeout(`${API_URL}/update-profile`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ userId, data })
        });
        return await res.json();
      } catch (e) {
          // Atualiza mock local também
          const idx = localMockUsers.findIndex(u => u.id === userId);
          if (idx !== -1) localMockUsers[idx] = { ...localMockUsers[idx], ...data };
          return { success: true };
      }
  },

  async getRechargeOptions() {
      try {
          const res = await fetchWithTimeout(`${API_URL}/recharge-options`);
          if (!res.ok) throw new Error("Server error");
          return await res.json();
      } catch (e) {
          return await mockServer.getRechargeOptions();
      }
  },

  async updateRechargeOption(id: string, qrCodeUrl: string) {
      try {
          const res = await fetchWithTimeout(`${API_URL}/update-recharge-option`, {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ id, qrCodeUrl })
          });
          return await res.json();
      } catch (e) {
          return { success: false };
      }
  },

  async getUsers() {
      try {
          const res = await fetchWithTimeout(`${API_URL}/admin/users`);
          if (!res.ok) throw new Error("Server error");
          return await res.json();
      } catch (e) {
          console.log("Fetching users from Local Mock");
          return await mockServer.getUsers();
      }
  },

  async addBalance(userId: string, amount: number) {
      try {
          const res = await fetchWithTimeout(`${API_URL}/admin/add-balance`, {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ userId, amount })
          });
          return await res.json();
      } catch (e) {
          return await mockServer.addBalance(userId, amount); 
      }
  },

  async approveDriver(userId: string) {
      try {
          const res = await fetchWithTimeout(`${API_URL}/admin/approve-driver`, {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ userId })
          });
          return await res.json();
      } catch(e) { return await mockServer.approveDriver(userId); }
  },

  async rejectDriver(userId: string) {
      try {
          const res = await fetchWithTimeout(`${API_URL}/admin/reject-driver`, {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ userId })
          });
          return await res.json();
      } catch(e) { return await mockServer.rejectDriver(userId); }
  },

  async banUser(userId: string) {
      try {
          const res = await fetchWithTimeout(`${API_URL}/admin/ban-user`, {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ userId })
          });
          return await res.json();
      } catch(e) { return await mockServer.banUser(userId); }
  },
  
  async getPricing() {
      try {
          const res = await fetchWithTimeout(`${API_URL}/pricing`);
          return await res.json();
      } catch(e) { return await mockServer.getPricing(); }
  },

  async updatePricing(pricing: PricingRules) {
      try {
          const res = await fetchWithTimeout(`${API_URL}/admin/pricing`, {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ pricing })
          });
          return await res.json();
      } catch(e) { return await mockServer.updatePricing(pricing); }
  },
  
  async reportError(data: any) {
      try {
          await fetch(`${API_URL}/report-error`, {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify(data)
          });
      } catch (e) {
          // Silently fail
      }
  },
  
  async getSystemErrors() {
      try {
          const res = await fetchWithTimeout(`${API_URL}/admin/errors`);
          if (!res.ok) throw new Error("Server error");
          return await res.json();
      } catch(e) {
          return await mockServer.getSystemErrors();
      }
  }
};
