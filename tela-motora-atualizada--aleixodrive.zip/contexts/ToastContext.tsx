import React, { createContext, useContext, useState, ReactNode, useCallback } from 'react';
import { ToastMessage, ToastType } from '../types';

interface ToastContextType {
  addToast: (message: string, type: ToastType) => void;
  removeToast: (id: string) => void;
}

const ToastContext = createContext<ToastContextType | undefined>(undefined);

export const ToastProvider = ({ children }: { children?: ReactNode }) => {
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  const addToast = useCallback((message: string, type: ToastType) => {
    const id = Math.random().toString(36).substr(2, 9);
    setToasts((prev) => [...prev, { id, message, type }]);

    // Auto remove after 4 seconds
    setTimeout(() => {
      removeToast(id);
    }, 4000);
  }, []);

  const removeToast = useCallback((id: string) => {
    setToasts((prev) => prev.filter((toast) => toast.id !== id));
  }, []);

  return (
    <ToastContext.Provider value={{ addToast, removeToast }}>
      {children}
      
      {/* Toast Container */}
      <div className="fixed top-20 right-4 z-[100] flex flex-col gap-2 pointer-events-none">
        {toasts.map((toast) => (
          <div 
            key={toast.id}
            className={`pointer-events-auto min-w-[280px] max-w-sm p-4 rounded-xl shadow-2xl border flex items-start gap-3 animate-slide-in relative overflow-hidden backdrop-blur-md transition-all
              ${toast.type === 'success' ? 'bg-green-500/90 text-white border-green-400' : ''}
              ${toast.type === 'error' ? 'bg-red-500/90 text-white border-red-400' : ''}
              ${toast.type === 'info' ? 'bg-blue-500/90 text-white border-blue-400' : ''}
              ${toast.type === 'warning' ? 'bg-yellow-500/90 text-white border-yellow-400' : ''}
            `}
          >
             {/* Icon */}
             <div className="text-xl">
                {toast.type === 'success' && '✅'}
                {toast.type === 'error' && '⚠️'}
                {toast.type === 'info' && 'ℹ️'}
                {toast.type === 'warning' && '🚧'}
             </div>
             
             <div className="flex-1">
                 <p className="font-bold text-sm leading-tight">{toast.message}</p>
             </div>

             <button 
                onClick={() => removeToast(toast.id)} 
                className="opacity-70 hover:opacity-100 text-xs font-bold uppercase"
             >
                ✕
             </button>
             
             {/* Progress Bar Animation */}
             <div className="absolute bottom-0 left-0 h-1 bg-white/40 animate-toast-progress w-full"></div>
          </div>
        ))}
      </div>
    </ToastContext.Provider>
  );
};

export const useToast = () => {
  const context = useContext(ToastContext);
  if (!context) throw new Error("useToast must be used within ToastProvider");
  return context;
};